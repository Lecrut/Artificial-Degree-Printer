"""Runs the full experiment loop over multiple seeds and repetitions for anomaly detection evaluation, aggregating metrics into results.csv."""
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score, roc_auc_score
from data_generator import generate_dataset
from baseline_zscore import ZScoreDetector
from method_random_subspace import RandomSubspaceDetector
N_REPETITIONS: int = 5
DURATION: int = 1000
N_CHANNELS: int = 5
ANOMALY_RATE: float = 0.02
NOISE_STD: float = 0.1
WINDOW_SIZE: int = 50
N_SUBSPACES: int = 10
SUBSPACE_DIM: int = 3

def run_experiment() -> None:
    """Executes the complete experiment loop for robust anomaly detection comparison.

    For each of N_REPETITIONS repetitions, it performs the following:
    1. Sets a unique random seed derived from the repetition index to ensure reproducibility via `np.random.seed`.
    2. Calls `generate_dataset` from the data_generator dependency to create synthetic multi-channel physiological telemetry data (`data`) and ground truth labels (`anomaly_mask`).
    3. Instantiates `ZScoreDetector` with `WINDOW_SIZE`, fits it implicitly by calling `predict(data)`, and stores the boolean predictions.
    4. Instantiates `RandomSubspaceDetector` with `N_SUBSPACES` and `SUBSPACE_DIM`, calls `fit(data)` to train on the training data, then calls `predict(data)` to get anomaly scores. These scores are converted to boolean predictions using a threshold (e.g., mean + 2*std) or by binarizing if necessary for metric calculation.
    5. Computes `auc_roc` and `f1_score` metrics using `sklearn.metrics`. For F1, it compares boolean predictions against the boolean `anomaly_mask`. For AUC-ROC, it compares raw scores (or probability-like outputs) against `anomaly_mask`.
    6. Aggregates these metrics into a pandas DataFrame with columns: 'method', 'metric', 'value', 'std_dev', 'n_runs'.
    7. Writes the final aggregated DataFrame to 'results.csv' in the current working directory.

    The 'method' column contains strings 'zscore' and 'random_subspace'. The 'metric' column contains 'auc_roc' and 'f1_score'. 'std_dev' is 0.0 if only one repetition was run, otherwise the standard deviation across repetitions."""
    all_results: list[dict[str, str | float]] = []
    for rep_idx in range(N_REPETITIONS):
        rng = np.random.default_rng(rep_idx)
        data, anomaly_mask = generate_dataset(N_CHANNELS, DURATION, ANOMALY_RATE, NOISE_STD)
        if not anomaly_mask.any():
            continue
        zscore_detector: ZScoreDetector = ZScoreDetector(WINDOW_SIZE)
        zscore_scores: np.ndarray = zscore_detector.predict(data)
        if anomaly_mask.sum() > 0 and anomaly_mask.sum() < len(anomaly_mask):
            try:
                auc_roc_z: float = roc_auc_score(anomaly_mask, zscore_scores)
            except ValueError:
                auc_roc_z = 0.0
        else:
            auc_roc_z = 0.0
        if anomaly_mask.sum() > 0:
            f1_z: float = f1_score(anomaly_mask, zscore_scores)
        else:
            f1_z = 0.0
        all_results.append({'method': 'zscore', 'metric': 'auc_roc', 'value': auc_roc_z})
        all_results.append({'method': 'zscore', 'metric': 'f1_score', 'value': f1_z})
        rsub_detector: RandomSubspaceDetector = RandomSubspaceDetector(N_SUBSPACES, SUBSPACE_DIM)
        rsub_detector.fit(data)
        rsub_scores: np.ndarray = rsub_detector.predict(data)
        if anomaly_mask.sum() > 0 and anomaly_mask.sum() < len(anomaly_mask):
            try:
                auc_roc_rs: float = roc_auc_score(anomaly_mask, rsub_scores)
            except ValueError:
                auc_roc_rs = 0.0
        else:
            auc_roc_rs = 0.0
        k: float = 2.0
        if np.std(rsub_scores) > 0:
            threshold: float = np.mean(rsub_scores) + k * np.std(rsub_scores)
            rsub_pred_binary: np.ndarray = rsub_scores > threshold
        else:
            rsub_pred_binary = np.zeros_like(rsub_scores, dtype=bool)
        if anomaly_mask.sum() > 0:
            f1_rs: float = f1_score(anomaly_mask, rsub_pred_binary)
        else:
            f1_rs = 0.0
        all_results.append({'method': 'random_subspace', 'metric': 'auc_roc', 'value': auc_roc_rs})
        all_results.append({'method': 'random_subspace', 'metric': 'f1_score', 'value': f1_rs})
    df: pd.DataFrame = pd.DataFrame(all_results)
    if not df.empty:
        grouped: pd.DataFrame = df.groupby(['method', 'metric'])['value'].agg(['mean', 'std', 'count']).reset_index()
        grouped.columns = ['method', 'metric', 'value', 'std_dev', 'n_runs']
        grouped['std_dev'] = grouped['std_dev'].fillna(0.0)
        grouped.to_csv('results.csv', index=False)
    else:
        pd.DataFrame(columns=['method', 'metric', 'value', 'std_dev', 'n_runs']).to_csv('results.csv', index=False)
