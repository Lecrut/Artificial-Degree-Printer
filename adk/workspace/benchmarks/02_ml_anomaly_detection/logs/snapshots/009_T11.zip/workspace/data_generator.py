"""Generates synthetic multi-channel physiological telemetry data with injected anomalies and known ground truth labels."""
import numpy as np
DEFAULT_DURATION: int = 1000
DEFAULT_N_CHANNELS: int = 5
DEFAULT_ANOMALY_RATE: float = 0.02
DEFAULT_NOISE_STD: float = 0.1

def generate_dataset(n_channels: int, duration: int, anomaly_rate: float, noise_std: float) -> tuple[np.ndarray, np.ndarray]:
    """Generates synthetic physiological signals with injected anomalies.

    Returns a tuple containing:
    1. `data`: A numpy array of shape (duration, n_channels) containing the synthetic telemetry signals.
    2. `anomaly_mask`: A boolean numpy array of shape (duration,) where True indicates an anomalous time step.

    The data is generated using random walks or sine waves with added Gaussian noise defined by `noise_std`. 
    Anomalies are injected according to `anomaly_rate` by modifying the signal values significantly at randomly selected indices.
    """
    if duration <= 0:
        return (np.empty((0, n_channels)), np.array([], dtype=bool))
    t = np.linspace(0, 10 * np.pi, duration)
    data = np.zeros((duration, n_channels))
    for ch in range(n_channels):
        freq = 1.0 + ch % 3 * 0.5
        phase = ch * np.pi / 4
        signal = np.sin(2 * np.pi * freq * t + phase)
        data[:, ch] = signal
    noise = np.random.normal(0, noise_std, data.shape)
    data += noise
    n_anomalies = int(duration * anomaly_rate)
    if n_anomalies == 0:
        n_anomalies = 1
    anomaly_indices = np.random.choice(duration, size=n_anomalies, replace=False)
    anomaly_mask = np.zeros(duration, dtype=bool)
    anomaly_mask[anomaly_indices] = True
    for idx in anomaly_indices:
        affected_channels = np.random.choice(n_channels, size=np.random.randint(1, n_channels + 1), replace=False)
        for ch in affected_channels:
            spike_magnitude = np.random.choice([-1, 1]) * (5 + np.random.uniform(0, 5)) * noise_std if noise_std > 0 else 10.0
            data[idx, ch] += spike_magnitude
    return (data, anomaly_mask)
