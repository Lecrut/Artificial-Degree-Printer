"""Implements the static univariate Z-score based anomaly detection baseline for multi-channel physiological telemetry."""
import numpy as np
from typing import Any

class ZScoreDetector:
    """A detector that flags anomalies in multi-channel physiological data using a static Z-score threshold computed over a rolling window for each channel."""
    window_size: int

    def __init__(self, window_size: int) -> None:
        """Initializes the detector with a fixed window size for local statistics calculation.

        Args:
            window_size: The size of the rolling window used to compute mean and standard deviation for each channel.
        """
        self.window_size = window_size

    def predict(self, channel_data: np.ndarray) -> np.ndarray:
        """Predicts anomalies for a 2D array of multi-channel data.

        Computes Z-scores using a rolling window of `window_size` independently for each channel. A time step is flagged as an anomaly if its absolute Z-score exceeds the threshold (typically 3.0) in ANY channel.

        Args:
            channel_data: A numpy array of shape (duration, n_channels) containing the telemetry signals.

        Returns:
            bool_array: A boolean numpy array of shape (duration,) where True indicates a detected anomaly at that time step.

        Edge cases:
        - If channel_data is empty (duration 0), returns an empty boolean array.
        - If the window size is larger than the data length, Z-scores are computed using all available preceding values for each point; standard deviation of 0 within the window results in Z-score of 0 (no anomaly) to avoid division by zero.
        """
        duration, n_channels = channel_data.shape
        if duration == 0:
            return np.array([], dtype=bool)

        # Initialize anomaly mask with False
        is_anomaly = np.zeros(duration, dtype=bool)
        
        # Static Z-score threshold for baseline
        THRESHOLD: float = 3.0

        for ch in range(n_channels):
            data_ch = channel_data[:, ch]
            window = self.window_size

            for t in range(duration):
                # Determine the indices for the rolling window ending at t
                start_idx = max(0, t - window + 1)
                end_idx = t + 1
                window_data = data_ch[start_idx:end_idx]
                
                # Compute mean and std dev of the window
                mean_val = np.mean(window_data)
                std_val = np.std(window_data, ddof=0) # Population std dev is standard for Z-score in this context
                
                # Avoid division by zero
                if std_val == 0:
                    z_score = 0.0
                else:
                    z_score = abs((data_ch[t] - mean_val) / std_val)
                
                if z_score > THRESHOLD:
                    is_anomaly[t] = True
        
        return is_anomaly