"""Implements the Random Subspace Ensemble detector for robust anomaly detection in physiological telemetry."""
import numpy as np


class RandomSubspaceDetector:
    """An ensemble anomaly detector that fits multiple independent sub-models on random subsets of features."""

    n_subspaces: int
    subspace_dim: int
    _means: list[np.ndarray]
    _covariances: list[np.ndarray]
    _subspace_indices: list[np.ndarray]

    def __init__(self, n_subspaces: int, subspace_dim: int) -> None:
        """Initializes the detector with the specified ensemble parameters.

        Args:
            n_subspaces: The number of random subspaces (sub-models) to train.
            subspace_dim: The dimensionality of each random subspace.
        """
        self.n_subspaces = n_subspaces
        self.subspace_dim = subspace_dim
        self._means: list[np.ndarray] = []
        self._covariances: list[np.ndarray] = []
        self._subspace_indices: list[np.ndarray] = []

    def fit(self, data: np.ndarray) -> None:
        """Trains the ensemble on the provided physiological telemetry data.

        For each of the n_subspaces, it randomly selects subspace_dim features,
        computes the mean and covariance of that subset, and stores them.

        Args:
            data: A 2D numpy array (n_samples, n_features) containing the training telemetry data.
        """
        self._means = []
        self._covariances = []
        self._subspace_indices = []

        n_samples, n_features = data.shape

        for _ in range(self.n_subspaces):
            # Randomly select subspace_dim unique features
            indices = np.random.choice(n_features, size=self.subspace_dim, replace=False)
            self._subspace_indices.append(indices)

            # Extract data for the selected subspace
            sub_data = data[:, indices]

            # Compute mean and covariance
            mean = np.mean(sub_data, axis=0)
            cov = np.cov(sub_data, rowvar=False)

            # Handle edge case where n_samples < subspace_dim or singular matrix
            if cov.ndim == 0:
                cov = np.array([[cov]])
            
            self._means.append(mean)
            self._covariances.append(cov)

    def predict(self, data: np.ndarray) -> np.ndarray:
        """Calculates anomaly scores for the input data based on the fitted ensemble.

        The final score is the average Mahalanobis distance squared across all subspaces.

        Args:
            data: A 2D numpy array (n_samples, n_features) containing the telemetry data to evaluate.

        Returns:
            A 1D numpy array of shape (n_samples,) with anomaly scores (higher means more anomalous).
        """
        n_samples = data.shape[0]
        scores = np.zeros(n_samples)

        for mean, cov in zip(self._means, self._covariances):
            indices = self._subspace_indices[self._means.index(mean)]
            sub_data = data[:, indices]

            # Calculate difference from mean
            diff = sub_data - mean  # Shape: (n_samples, subspace_dim)

            # Solve for inverse covariance or pseudo-inverse
            try:
                cov_inv = np.linalg.inv(cov)
            except np.linalg.LinAlgError:
                cov_inv = np.linalg.pinv(cov)

            # Mahalanobis distance squared: d^2 = (x - mu)^T * Cov^-1 * (x - mu)
            # We compute this for each sample efficiently using matrix multiplication.
            # temp = diff @ cov_inv
            # scores += np.sum(temp * diff, axis=1)
            
            # More numerically stable way often used:
            # Solve L x = diff^T where L is cholesky of cov. Then sum squares of x.
            try:
                L = np.linalg.cholesky(cov + 1e-6 * np.eye(cov.shape[0])) # Add jitter for stability
                temp = np.linalg.solve(L, diff.T)
                scores += np.sum(temp ** 2, axis=0)
            except np.linalg.LinAlgError:
                # Fallback to inverse if cholesky fails
                temp = diff @ cov_inv
                scores += np.sum(temp * diff, axis=1)

        return scores / len(self._means)