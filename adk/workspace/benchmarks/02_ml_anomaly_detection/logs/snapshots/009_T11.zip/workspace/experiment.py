"""Runs the full experiment loop over multiple seeds and repetitions for anomaly detection evaluation, aggregating metrics into results.csv."""
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score, roc_auc_score
from data_generator import generate_dataset
from baseline_zscore import ZScoreDetector
from method_random_subspace import RandomSubspaceDetector
N_REPETITIONS: int = 5
DURATION: int = 1000
N_CHANNELS: int = 5
ANOMALY_RATE: float = 0.02
NOISE_STD: float = 0.1
WINDOW_SIZE: int = 50
N_SUBSPACES: int = 10
SUBSPACE_DIM: int = 3

def run_experiment() -> None:
    """Executes the complete experiment loop. For each of N_REPETITIONS, it generates synthetic multi-channel physiological telemetry data using generate_dataset with a unique seed (controlled by np.random). It then fits both the ZScoreDetector and RandomSubspaceDetector on the generated data. Anomaly scores/predictions are obtained for both methods. The function computes auc_roc and f1_score metrics using sklearn.metrics functions, comparing predictions against the ground truth anomaly_mask. Results are aggregated into a pandas DataFrame with columns: method, metric, value, std_dev, n_runs. Finally, it writes this DataFrame to 'results.csv' in the current working directory. The method column will contain 'zscore' and 'random_subspace'. The metric column will contain 'auc_roc' and 'f1_score'. Std_dev is computed across repetitions if n_runs > 1, otherwise it is 0.0."""
    raise NotImplementedError
