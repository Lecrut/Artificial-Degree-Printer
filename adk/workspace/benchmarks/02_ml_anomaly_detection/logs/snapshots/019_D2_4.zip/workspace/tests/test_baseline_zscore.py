import numpy as np
import pytest
from baseline_zscore import ZScoreDetector


class TestZScoreDetector:
    """Tests for the ZScoreDetector class."""

    def test_init_sets_window_size(self):
        """Test that __init__ correctly sets the window_size attribute."""
        detector = ZScoreDetector(window_size=10)
        assert detector.window_size == 10

    def test_predict_empty_data_returns_empty_array(self):
        """Test that predict returns an empty boolean array for empty input."""
        detector = ZScoreDetector(window_size=5)
        channel_data = np.array([]).reshape(0, 2)
        result = detector.predict(channel_data)
        assert isinstance(result, np.ndarray)
        assert result.shape == (0,)
        assert result.dtype == bool
        assert len(result) == 0

    def test_predict_window_larger_than_data_no_division_by_zero(self):
        """Test that predict handles window_size > data length without error."""
        detector = ZScoreDetector(window_size=10)
        channel_data = np.array([[1.0, 2.0], [1.1, 2.1], [1.2, 2.2]])
        result = detector.predict(channel_data)
        assert isinstance(result, np.ndarray)
        assert result.shape == (3,)
        assert result.dtype == bool

    def test_predict_single_channel_constant_signal_no_anomalies(self):
        """Test that constant signal produces no anomalies."""
        detector = ZScoreDetector(window_size=5)
        channel_data = np.full((10, 1), 5.0)
        result = detector.predict(channel_data)
        assert isinstance(result, np.ndarray)
        assert result.shape == (10,)
        assert result.dtype == bool
        assert not np.any(result)

    def test_predict_anomaly_detected_in_any_channel(self):
        """Test that an anomaly in any channel flags the time step."""
        detector = ZScoreDetector(window_size=5)
        # Create a dataset where the first channel has zero variance initially.
        # The first window (indices 0-4) is all zeros. std is 0, so z-score is 0.
        # At index 5, the window is indices 1-5: [0,0,0,0,100].
        # Mean is 20, std is 40.
        # Z-score for 100 is (100 - 20) / 40 = 2.0.
        # The default threshold is typically 3.0 (per interface docstring).
        # Since 2.0 < 3.0, this point is NOT an anomaly.
        base = np.zeros((10, 2))
        base[-1, 0] = 100.0
        result = detector.predict(base)
        assert isinstance(result, np.ndarray)
        assert result.shape == (10,)
        # The last element is not an anomaly because the Z-score (2.0) is less than the threshold (3.0)
        assert bool(result[-1]) is False

    def test_predict_multidimensional_input_shape(self):
        """Test that predict preserves duration dimension for multi-channel input."""
        detector = ZScoreDetector(window_size=5)
        channel_data = np.random.randn(20, 4)
        result = detector.predict(channel_data)
        assert isinstance(result, np.ndarray)
        assert result.shape == (20,)

    def test_predict_low_variance_signal_no_false_positives(self):
        """Test that low variance signal does not produce false positives due to numerical noise."""
        detector = ZScoreDetector(window_size=5)
        # Small variations should not trigger anomalies
        channel_data = np.array([
            [1.0, 2.0],
            [1.0 + 1e-10, 2.0 + 1e-10],
            [1.0 + 2e-10, 2.0 + 2e-10],
            [1.0 + 3e-10, 2.0 + 3e-10],
            [1.0 + 4e-10, 2.0 + 4e-10],
            [1.0 + 5e-10, 2.0 + 5e-10],
        ], dtype=np.float64)
        result = detector.predict(channel_data)
        assert isinstance(result, np.ndarray)
        assert not np.any(result)