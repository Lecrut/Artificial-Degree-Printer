"""Runs the full experiment loop over multiple seeds and repetitions for anomaly detection evaluation, aggregating metrics into results.csv."""
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score, roc_auc_score
from data_generator import generate_dataset
from baseline_zscore import ZScoreDetector
from method_random_subspace import RandomSubspaceDetector
N_REPETITIONS: int = 5
DURATION: int = 1000
N_CHANNELS: int = 5
ANOMALY_RATE: float = 0.02
NOISE_STD: float = 0.1
WINDOW_SIZE: int = 50
N_SUBSPACES: int = 10
SUBSPACE_DIM: int = 3

def run_experiment() -> None:
    """Executes the complete experiment loop for robust anomaly detection evaluation.

    For each of N_REPETITIONS, generates synthetic multi-channel physiological telemetry data,
    fits both ZScoreDetector and RandomSubspaceDetector, computes metrics (auc_roc, f1_score),
    and aggregates results into results.csv.
    """
    all_results: list[dict[str, str | float]] = []
    for rep_idx in range(N_REPETITIONS):
        rng = np.random.default_rng(rep_idx)
        data, anomaly_mask = generate_dataset(n_channels=N_CHANNELS, duration=DURATION, anomaly_rate=ANOMALY_RATE, noise_std=NOISE_STD)
        if not anomaly_mask.any():
            continue
        zscore_detector = ZScoreDetector(window_size=WINDOW_SIZE)
        zscore_pred = zscore_detector.predict(data)
        try:
            auc_roc_z = roc_auc_score(anomaly_mask, zscore_pred.astype(float))
        except ValueError:
            auc_roc_z = 0.0
        try:
            f1_z = f1_score(anomaly_mask, zscore_pred.astype(bool))
        except ValueError:
            f1_z = 0.0
        all_results.append({'method': 'zscore', 'metric': 'auc_roc', 'value': auc_roc_z})
        all_results.append({'method': 'zscore', 'metric': 'f1_score', 'value': f1_z})
        rsub_detector = RandomSubspaceDetector(n_subspaces=N_SUBSPACES, subspace_dim=SUBSPACE_DIM)
        rsub_detector.fit(data)
        rsub_scores = rsub_detector.predict(data)
        try:
            auc_roc_rs = roc_auc_score(anomaly_mask, rsub_scores)
        except ValueError:
            auc_roc_rs = 0.0
        threshold = np.mean(rsub_scores) + np.std(rsub_scores)
        rsub_pred_binary = rsub_scores > threshold
        try:
            f1_rs = f1_score(anomaly_mask, rsub_pred_binary)
        except ValueError:
            f1_rs = 0.0
        all_results.append({'method': 'random_subspace', 'metric': 'auc_roc', 'value': auc_roc_rs})
        all_results.append({'method': 'random_subspace', 'metric': 'f1_score', 'value': f1_rs})
    df = pd.DataFrame(all_results)
    if not df.empty:
        grouped = df.groupby(['method', 'metric'])['value'].agg(['mean', 'std', 'count']).reset_index()
        grouped.columns = ['method', 'metric', 'value', 'std_dev', 'n_runs']
        grouped['std_dev'] = grouped['std_dev'].fillna(0.0)
    else:
        grouped = pd.DataFrame(columns=['method', 'metric', 'value', 'std_dev', 'n_runs'])
    if not grouped.empty:
        grouped.to_csv('results.csv', index=False)
    else:
        pd.DataFrame(columns=['method', 'metric', 'value', 'std_dev', 'n_runs']).to_csv('results.csv', index=False)
