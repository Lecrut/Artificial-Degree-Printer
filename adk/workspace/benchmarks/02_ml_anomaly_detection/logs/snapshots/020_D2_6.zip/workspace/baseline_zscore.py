"""Implements the static univariate Z-score based anomaly detection baseline for multi-channel physiological telemetry."""
import numpy as np
from typing import Any

class ZScoreDetector:
    """A detector that flags anomalies in multi-channel physiological data using a Z-score threshold computed over a rolling window for each channel."""
    window_size: int

    def __init__(self, window_size: int) -> None:
        """Initializes the detector with a fixed window size for local statistics calculation. The Z-score threshold is implicitly set to standard values (typically 3.0) as per the static baseline definition."""
        self.window_size = window_size

    def predict(self, data: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Predicts anomalies for a 2D array of multi-channel data.

Computes Z-scores using a rolling window of `window_size` independently for each channel.
A time step is flagged as an anomaly if its absolute Z-score exceeds the threshold (typically 3.0) in ANY channel.

Args:
    data: A numpy array of shape (duration, n_channels) containing the telemetry signals.

Returns:
    bool_array: A boolean numpy array of shape (duration,) where True indicates a detected anomaly at that time step.
    max_abs_z_scores: A float numpy array of shape (duration,) where each value is the maximum absolute Z-score across all channels for that time step.
"""
        duration: int = data.shape[0]
        if duration == 0:
            return (np.array([], dtype=bool), np.array([], dtype=float))
        n_channels: int = data.shape[1]
        bool_array: np.ndarray = np.zeros(duration, dtype=bool)
        max_abs_z_scores: np.ndarray = np.zeros(duration, dtype=float)
        for j in range(n_channels):
            channel_data: np.ndarray = data[:, j]
            z_scores_channel: np.ndarray = np.zeros(duration, dtype=float)
            for i in range(duration):
                start_idx: int = max(0, i - self.window_size + 1)
                window_vals: np.ndarray = channel_data[start_idx:i + 1]
                w_len: int = len(window_vals)
                if w_len < 2:
                    z_scores_channel[i] = 0.0
                else:
                    mean_val: float = np.mean(window_vals)
                    std_val: float = np.std(window_vals, ddof=0)
                    if std_val < 1e-08:
                        z_scores_channel[i] = 0.0
                    else:
                        z_scores_channel[i] = (channel_data[i] - mean_val) / std_val
                current_max_z: float = max_abs_z_scores[i]
                abs_z: float = abs(z_scores_channel[i])
                if abs_z > current_max_z:
                    max_abs_z_scores[i] = abs_z
                if abs_z > 3.0:
                    bool_array[i] = True
        return (bool_array, max_abs_z_scores)
