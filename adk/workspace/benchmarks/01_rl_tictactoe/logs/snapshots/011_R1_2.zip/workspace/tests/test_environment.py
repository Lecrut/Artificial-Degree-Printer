from environment import TicTacToeEnv, run_episode, parse_episode_result
import numpy as np
import gymnasium as gym

def test_tic_tac_toe_env_init():
    """Test initialization of TicTacToeEnv creates valid spaces and initial board."""
    env = TicTacToeEnv()
    assert isinstance(env.observation_space, gym.spaces.Box)
    assert len(env.observation_space.shape) == 2
    assert env.observation_space.high[0] == 2
    assert isinstance(env.action_space, gym.spaces.Discrete)
    assert env.action_space.n == 9
    assert np.array_equal(env.reset()[0], [2] * 9)
