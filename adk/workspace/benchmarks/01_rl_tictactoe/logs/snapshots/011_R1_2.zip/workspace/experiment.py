"""Orchestrates the training and evaluation of both a Q-Learning agent and a Random baseline agent in Tic-Tac-Toe across multiple seeds, writing aggregated results to results.csv."""
from typing import Any, Dict, List
import config
import environment
import agent
import baseline
import numpy as np
import pandas as pd

def run_experiment() -> None:
    """Runs the full experiment pipeline for both Q-Learning and Random baseline agents.

    This function performs two distinct phases of experimentation, repeated for each seed in `config.SEEDS`:
    1. Q-Learning Training & Evaluation: Initializes a `QLearningAgent`, trains it against a fixed `RandomAgent` opponent for `config.NUM_EPISODES` episodes using epsilon-greedy policy with decay. After training, evaluates the trained agent against the same `RandomAgent` for `config.TEST_EPISODES` episodes.
    2. Random Baseline Evaluation: Initializes a `RandomAgent` as Player 1 (P1) and another `RandomAgent` as Player 2. Plays `config.TEST_EPISODES` episodes to establish baseline metrics for win/loss/draw rates against itself.

    Metrics collected per method ('q_learning' and 'random_baseline') include: win_rate, loss_rate, draw_rate, and avg_reward. These are aggregated across all seeds and episodes, then written to a CSV file named `results.csv` in the current working directory with columns: `method`, `metric`, `value`. If an optional column `std_dev` is computed, it is included; otherwise, it is omitted.

    Conventions:
    - P1 is the agent being evaluated or trained. P2 is always a RandomAgent.
    - In the Q-Learning phase, P1 learns against P2's fixed random policy.
    - In the Baseline phase, both P1 and P2 play randomly to determine baseline performance.
    - `results.csv` contains one row per metric per method.

    Edge cases:
    - If `config.SEEDS` is empty, raises `ValueError`.
    - If `config.NUM_EPISODES` is less than 1, it defaults to 1.
    - If `config.TEST_EPISODES` is less than 1, it defaults to 1."""
    if not config.SEEDS:
        raise ValueError('No seeds provided in configuration.')
    results_data: list[dict[str, Any]] = []
    rng_base: np.random.Generator = np.random.default_rng()
    q_agent: agent.QLearningAgent = agent.QLearningAgent(num_states=int(np.prod(env.TicTacToeEnv().observation_space.shape)), num_actions=int(env.TicTacToeEnv().action_space.n), lr=config.LEARNING_RATE, gamma=config.GAMMA, epsilon=config.EPSILON_START)
    r_agent: baseline.RandomAgent = baseline.RandomAgent()
    train_rewards: list[float] = []
    train_wins: int = 0
    train_losses: int = 0
    train_draws: int = 0
    for seed in config.SEEDS:
        rng_episode: np.random.Generator = np.random.default_rng(seed)
        env_train: environment.TicTacToeEnv = environment.TicTacToeEnv()
        for ep_idx in range(config.NUM_EPISODES):
            obs, _ = env_train.reset(seed=int(rng_episode.integers(0, 2 ** 31)))
            current_epsilon: float = max(config.EPSILON_END, config.EPSILON_START * config.EPSILON_DECAY ** ep_idx)
            q_agent.epsilon = current_epsilon
            total_ep_reward: float = 0.0
            done: bool = False
            truncated: bool = False
            while not (done or truncated):
                valid_actions: list[int] = env_train.get_valid_actions(obs)
                if not valid_actions:
                    break
                action: int = q_agent.choose_action(state=int(np.sum(obs * np.arange(9)[:, None].T)), valid_actions=valid_actions)
                obs, reward, done, truncated, info = env_train.step(action)
                total_ep_reward += reward
                if done or truncated:
                    next_state: int = 0
                else:
                    next_state = int(np.sum(obs * np.arange(9)[:, None].T))
                q_agent.update(state=int(np.sum((obs if done else obs) * np.arange(9)[:, None].T)), action=action, reward=reward, next_state=next_state, done=done or truncated)
            train_rewards.append(total_ep_reward)
            winner: str | None = info.get('winner')
            if winner == 'X':
                train_wins += 1
            elif winner == 'O':
                train_losses += 1
            else:
                train_draws += 1
        eval_wins: int = 0
        eval_losses: int = 0
        eval_draws: int = 0
        eval_rewards: list[float] = []
        for ep_idx in range(config.TEST_EPISODES):
            env_eval: environment.TicTacToeEnv = environment.TicTacToeEnv()
            obs, _ = env_eval.reset(seed=int(rng_episode.integers(0, 2 ** 31)))
            total_ep_reward = 0.0
            done = False
            truncated = False
            while not (done or truncated):
                valid_actions = env_eval.get_valid_actions(obs)
                if not valid_actions:
                    break
                action: int = q_agent.choose_action(state=int(np.sum(obs * np.arange(9)[:, None].T)), valid_actions=valid_actions)
                obs, reward, done, truncated, info = env_eval.step(action)
                total_ep_reward += reward
                if not (done or truncated):
                    valid_actions_o: list[int] = env_eval.get_valid_actions(obs)
                    if valid_actions_o:
                        action_o: int = r_agent.choose_action(valid_actions=valid_actions_o, rng=rng_episode)
                        obs, reward_o, done, truncated, info = env_eval.step(action_o)
                        total_ep_reward += reward_o
            eval_rewards.append(total_ep_reward)
            winner = info.get('winner')
            if winner == 'X':
                eval_wins += 1
            elif winner == 'O':
                eval_losses += 1
            else:
                eval_draws += 1
        results_data.append({'method': 'q_learning', 'episodes': config.NUM_EPISODES, 'train_reward': np.mean(train_rewards), 'train_win_rate': train_wins / config.NUM_EPISODES, 'train_loss_rate': train_losses / config.NUM_EPISODES, 'train_draw_rate': train_draws / config.NUM_EPISODES, 'eval_reward': np.mean(eval_rewards), 'eval_win_rate': eval_wins / config.TEST_EPISODES, 'eval_loss_rate': eval_losses / config.TEST_EPISODES, 'eval_draw_rate': eval_draws / config.TEST_EPISODES})
    base_wins: int = 0
    base_losses: int = 0
    base_draws: int = 0
    base_rewards: list[float] = []
    for seed in config.SEEDS:
        rng_base: np.random.Generator = np.random.default_rng(seed)
        r_agent1: baseline.RandomAgent = baseline.RandomAgent()
        r_agent2: baseline.RandomAgent = baseline.RandomAgent()
        for ep_idx in range(config.TEST_EPISODES):
            env_base: environment.TicTacToeEnv = environment.TicTacToeEnv()
            obs, _ = env_base.reset(seed=int(rng_base.integers(0, 2 ** 31)))
            total_ep_reward = 0.0
            done = False
            truncated = False
            while not (done or truncated):
                valid_actions = env_base.get_valid_actions(obs)
                if not valid_actions:
                    break
                action: int = r_agent1.choose_action(valid_actions=valid_actions, rng=rng_base)
                obs, reward, done, truncated, info = env_base.step(action)
                total_ep_reward += reward
                if not (done or truncated):
                    valid_actions_o = env_base.get_valid_actions(obs)
                    if valid_actions_o:
                        action_o: int = r_agent2.choose_action(valid_actions=valid_actions_o, rng=rng_base)
                        obs, reward_o, done, truncated, info = env_base.step(action_o)
                        total_ep_reward += reward_o
            base_rewards.append(total_ep_reward)
            winner = info.get('winner')
            if winner == 'X':
                base_wins += 1
            elif winner == 'O':
                base_losses += 1
            else:
                base_draws += 1
    results_data.append({'method': 'random_baseline', 'episodes': config.TEST_EPISODES, 'train_reward': 0.0, 'train_win_rate': 0.0, 'train_loss_rate': 0.0, 'train_draw_rate': 0.0, 'eval_reward': np.mean(base_rewards), 'eval_win_rate': base_wins / config.TEST_EPISODES, 'eval_loss_rate': base_losses / config.TEST_EPISODES, 'eval_draw_rate': base_draws / config.TEST_EPISODES})
    df: pd.DataFrame = pd.DataFrame(results_data)
