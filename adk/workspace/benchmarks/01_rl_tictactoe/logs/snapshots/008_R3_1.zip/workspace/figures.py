"""Reads experiment results and training history to generate static plots."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
import pandas as pd
from typing import List
FIGURES_DIR: str = 'figures'

def plot_results() -> None:
    """Read `results.csv` and `training_history.csv`, generate and save plots.

    Reads two files from the workspace root:
    1. `results.csv`: Contains final aggregated metrics (`method`, `metric`, `value`).
       Used for the payoff comparison bar chart (win/draw/loss rates).
    2. `training_history.csv`: Contains training progress (`episode`, `reward`).
       Used for the learning curve visualization.

    Generates two figures and saves them into the `figures/` directory:
    1. `q_learning_curve.png`: Line plot of average reward over episodes.
    2. `payoff_comparison.png`: Bar chart comparing win/draw/loss rates between methods.

    Ensures the `figures/` directory exists before saving.
    """
    os.makedirs(FIGURES_DIR, exist_ok=True)
    try:
        df_results = pd.read_csv('results.csv')
        df_history = pd.read_csv('training_history.csv')
    except FileNotFoundError as e:
        raise FileNotFoundError(f'Experiment data files not found. Please run the experiment first. Error: {e}')
    methods = df_results['method'].unique()
    fig_payoff, ax_payoff = plt.subplots(figsize=(8, 6))
    x_indices: list[int] = []
    labels: list[str] = []
    for i, method in enumerate(methods):
        wins = df_results.loc[(df_results['method'] == method) & (df_results['metric'] == 'win_rate'), 'value']
        draws = df_results.loc[(df_results['method'] == method) & (df_results['metric'] == 'draw_rate'), 'value']
        losses = df_results.loc[(df_results['method'] == method) & (df_results['metric'] == 'loss_rate'), 'value']
        val_win: float = wins.values[0] if len(wins) > 0 else 0.0
        val_draw: float = draws.values[0] if len(draws) > 0 else 0.0
        val_loss: float = losses.values[0] if len(losses) > 0 else 0.0
        x_indices.append(i)
        labels.append(method.replace('_', ' ').title())
        ax_payoff.bar(i, val_win, color='green', label='Win' if method == methods[0] else '')
        ax_payoff.bar(i, val_draw, bottom=val_win, color='gray', label='Draw' if method == methods[0] else '')
        ax_payoff.bar(i, val_loss, bottom=val_win + val_draw, color='red', label='Loss' if method == methods[0] else '')
    ax_payoff.set_xticks(x_indices)
    ax_payoff.set_xticklabels(labels)
    ax_payoff.set_ylabel('Rate')
    ax_payoff.set_title('Payoff Comparison (Win/Draw/Loss)')
    ax_payoff.legend(loc='upper right')
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR, 'payoff_comparison.png'), bbox_inches='tight')
    plt.close(fig_payoff)
    if len(df_history) > 0:
        fig_curve, ax_curve = plt.subplots(figsize=(10, 6))
        df_history_sorted = df_history.sort_values(by='episode')
        episodes: list[float] = df_history_sorted['episode'].values.tolist()
        avg_rewards: list[float] = df_history_sorted['avg_reward'].values.tolist()
        ax_curve.plot(episodes, avg_rewards, marker='o', linestyle='-', color='#b22232', label='Avg Reward')
        ax_curve.set_title('Average Reward Over Episodes (Q-Learning)')
        ax_curve.set_xlabel('Episode')
        ax_curve.set_ylabel('Average Reward')
        ax_curve.legend(loc='lower right')
        ax_curve.grid(True, linestyle='--', alpha=0.6)
        plt.tight_layout()
        plt.savefig(os.path.join(FIGURES_DIR, 'q_learning_curve.png'), bbox_inches='tight')
        plt.close(fig_curve)
