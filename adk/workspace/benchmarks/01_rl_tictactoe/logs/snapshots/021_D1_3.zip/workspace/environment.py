"""Provides a custom Tic-Tac-Toe Gymnasium environment where observations are integer state hashes compatible with direct Q-table indexing."""

import gymnasium as gym
from gymnasium import spaces
import numpy as np
from typing import Tuple, Dict, Any, Optional, List

BOARD_SIZE: int = 3
NUM_ACTIONS: int = 9
PLAYER_X: int = 1
PLAYER_O: int = -1
DRAW_REWARD: float = 0.5
WIN_REWARD: float = 1.0
LOSS_REWARD: float = -1.0


class TicTacToeEnv(gym.Env):
    """A Tic-Tac-Toe environment implementing the Gymnasium API.

    The environment manages a 3x3 board. The agent plays as Player X (value 1). Actions are indices 0-8 corresponding to empty cells. The observation is an integer hash of the board state, suitable for direct Q-table indexing."""
    
    observation_space: spaces.Discrete
    action_space: spaces.Discrete

    def __init__(self) -> None:
        """Initializes the environment. Sets up observation and action spaces."""
        super().__init__()
        self.observation_space = spaces.Discrete(pow(3, BOARD_SIZE * BOARD_SIZE))
        self.action_space = spaces.Discrete(NUM_ACTIONS)
        self.board: np.ndarray = np.zeros((BOARD_SIZE, BOARD_SIZE), dtype=int)

    def reset(self, seed: Optional[int] = None, options: Optional[Dict[str, Any]] = None) -> Tuple[int, Dict[str, Any]]:
        """Resets the environment to the initial empty board state.

        Returns:
            tuple: A tuple containing the initial observation (integer hash of empty board) and an info dict (empty)."""
        super().reset(seed=seed)
        self.board = np.zeros((BOARD_SIZE, BOARD_SIZE), dtype=int)
        return self.get_state_hash(self.board), {}

    def step(self, action: int) -> Tuple[int, float, bool, bool, Dict[str, Any]]:
        """Processes one time step.

        Args:
            action: An integer 0-8 representing the chosen cell.

        Returns:
            tuple: (observation, reward, terminated, truncated, info)
                - observation: The integer hash of the new board state.
                - reward: Reward for the agent (+1 if win, -1 if loss, +0.5 if draw, 0 otherwise).
                - terminated: True if the game ended by win/loss/draw.
                - truncated: Always False (no time limit within an episode).
                - info: Dict containing 'valid_move' and 'winner' information."""
        # Check if action is valid
        if action not in self.get_valid_moves():
            return self.get_state_hash(self.board), 0.0, False, False, {'valid_move': False, 'winner': None}

        # Agent moves (Player X)
        row: int = action // BOARD_SIZE
        col: int = action % BOARD_SIZE
        self.board[row, col] = PLAYER_X

        # Check if agent won or draw
        winner: Optional[int] = self._check_winner()
        if winner is not None:
            reward: float = WIN_REWARD if winner == PLAYER_X else LOSS_REWARD
            if winner == 0:
                reward = DRAW_REWARD
            return self.get_state_hash(self.board), reward, True, False, {'valid_move': True, 'winner': winner}

        # Opponent moves (Player O) - Random strategy
        opp_moves: List[int] = self.get_valid_moves()
        if not opp_moves:
            return self.get_state_hash(self.board), DRAW_REWARD, True, False, {'valid_move': True, 'winner': 0}
            
        opp_action: int = np.random.choice(opp_moves)
        r_opp: int = opp_action // BOARD_SIZE
        c_opp: int = opp_action % BOARD_SIZE
        self.board[r_opp, c_opp] = PLAYER_O

        # Check if opponent won or draw after opponent move
        winner = self._check_winner()
        if winner is not None:
            reward = WIN_REWARD if winner == PLAYER_X else LOSS_REWARD
            if winner == 0:
                reward = DRAW_REWARD
            return self.get_state_hash(self.board), reward, True, False, {'valid_move': True, 'winner': winner}

        # Game continues
        return self.get_state_hash(self.board), 0.0, False, False, {'valid_move': True, 'winner': None}

    def get_state_hash(self, state: np.ndarray) -> int:
        """Computes the integer hash for a given numpy board array.

        Args:
            state: A 3x3 numpy array representing the board.

        Returns:
            int: A unique integer identifier for the state."""
        # Encode board state into a base-3 number converted to integer
        # Flatten board and treat as digits in base 3 (0, 1, -1 mapped to 0, 1, 2)
        flattened = state.flatten()
        # Map: -1 -> 0, 0 -> 1, 1 -> 2 so that we can use standard base conversion
        # Actually, simpler: just sum powers of 3
        val: int = 0
        for i, cell in enumerate(flattened):
            if cell != 0:
                val += (cell + 1) * (3 ** i)
        return val

    def get_valid_moves(self) -> List[int]:
        """Returns the list of valid actions for the current state.

        Returns:
            list: List of integers representing available moves."""
        return [i for i in range(NUM_ACTIONS) if self.board[i // BOARD_SIZE, i % BOARD_SIZE] == 0]

    def _check_winner(self) -> Optional[int]:
        """Checks if there is a winner or if the board is full.

        Returns:
            Optional[int]: PLAYER_X (1) if X wins, PLAYER_O (-1) if O wins, 0 for draw, None if game continues."""
        # Check rows
        for i in range(BOARD_SIZE):
            if np.sum(self.board[i, :]) == BOARD_SIZE * PLAYER_X:
                return PLAYER_X
            if np.sum(self.board[i, :]) == BOARD_SIZE * PLAYER_O:
                return PLAYER_O
        
        # Check columns
        for j in range(BOARD_SIZE):
            if np.sum(self.board[:, j]) == BOARD_SIZE * PLAYER_X:
                return PLAYER_X
            if np.sum(self.board[:, j]) == BOARD_SIZE * PLAYER_O:
                return PLAYER_O
        
        # Check diagonals
        if np.sum(np.diagonal(self.board)) == BOARD_SIZE * PLAYER_X:
            return PLAYER_X
        if np.sum(np.diagonal(np.fliplr(self.board))) == BOARD_SIZE * PLAYER_X:
            return PLAYER_X
        if np.sum(np.diagonal(self.board)) == BOARD_SIZE * PLAYER_O:
            return PLAYER_O
        if np.sum(np.diagonal(np.fliplr(self.board))) == BOARD_SIZE * PLAYER_O:
            return PLAYER_O
        
        # Check draw
        if np.all(self.board != 0):
            return 0
            
        return None
