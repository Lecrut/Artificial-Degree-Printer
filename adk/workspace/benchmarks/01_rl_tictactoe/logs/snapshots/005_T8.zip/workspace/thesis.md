## Rozdział 2: Fundamenty Teoretyczne i Klasyfikacja Problemu Właściwości
### 2.1 Fundamenty Teoretyczne i Klasyczna Formułacja Przestrogi

Przedstawiona praca opiera się na paradygmatie uczenia maszynowego, konkretnie metodach bezprzepustowych (model-free) nazywanych uczeniem ze wzmocnieniem (Reinforcement Learning - RL). W tej dziedzinie kluczowym elementem jest formalizacja procesu decyzyjnego jako Procesu Decyzyjnego Markowa (MDP). MDP stanowi matematyczny framework, który charakteryzuje się czterema komponentami: zbiorem stanów $S$, zbiorem akcji $A$, funkcją prawdopodobieństwa przejścia stanu $P(s'|s,a)$ oraz funkcję wartości oczekiwanej nagrody $R(s,a,s')$. Jak podsuwa literaturza, modelowanie świata jako MDP pozwala na zastosowanie dynamicznego programowania do optymalizacji polityk decyzyjnych \cite{amiri2025reinforcemen}.

Głównym narzędziem badawczym w tej pracy jest algorytm Q-Learning, który należałby do klasy algorytmów tabularowych. Algorytm ten uczy się polityki bez wykorzystania modelu otoczenia, poprzez iteracyjną aktualizację tabeli wartości funkcji $Q(s,a)$, która szacuje wartość długoterminową wykonania akcji $a$ w stanie $s$. Aktualizacja odbywa się na podstawie równania Bellmana 
$$
Q(s,a) \leftarrow Q(s,a) + \alpha [r + \gamma \max_{a'} Q(s',a') - Q(s,a)]
$$
gdzie $\alpha$ jest parametrem szybkości nauki, a $\gamma$ oznacza zysk dyskontowany za przyszłe stany \cite{hwang2023practical}. Zbieżność tego algorytmu do optymalnej wartości funkcji $Q^*$ jest gwarantowana w środowiskach skończonych po zakończeniu, przy odpowiednim dostosowaniu parametrów eksploracji i eksploatacji (tzw. epsilon-greedy) \cite{deka2022arc}.

W kontekście gier deterministycznych, takich jak Kółko i Krzyżyk, problem przedstawia się jako MDP o skończonym horyzoncie. W takim przypadku nie ma potrzeby rozstrzygania problemu planowania dynamicznego na czas przyszły, ponieważ wartość końcowa jest znana dla każdego stanu końcowego (stan zwycięstwa lub remisu) \cite{wang2021sampleeffici}.

Należy zaznaczyć, że choć literatura sugeruje korzyści z użycia wartości funkcyjnych jako funkcji aproksymujących w dużych przestrzeniach stanów \cite{yang2023federated}, w tej pracy przyjęto model tabularny ze względu na ograniczoną liczbę stanów planszy (max 9!/6 = 25,771 symetrickie). Wybór modelu jest zgodny z praktyką stosowaną w wielu zastosowaniach AI \cite{yang2026lifted}.
