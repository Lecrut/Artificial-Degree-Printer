## Rozdział 1: Wprowadzenie do Uczenia ze Wzmocnieniem
Współczesne podejścia do sztucznej inteligencji ewoluowały od systemów opartych na sztywnych, hand-coded regułach w kierunku algorytmów zdolnych do autonomicznej adaptacji poprzez interakcję z otaczającym światem. Centralnym filarem tej transformacji jest uczenie ze wzmocnieniem (Reinforcement Learning, RL), które definiuje naukę jako proces optymalizacji strategii decyzyjnej agenta działającego w niepełnym środowisku. Celem niniejszej pracy inżynierskiej jest zbadanie skuteczności klasycznej, tabelarycznej metody Q-Learning w kontekście gry w kółko i krzyżyk (Tic-Tac-Toe) przeciwko przeciwnikowi losowemu.

### 1.1 Fundamentalne pojęcia uczenia ze wzmocnieniem

Proces uczenia się opiera się na czterech fundamentalnych elementach: agencie, środowisku, stanie oraz nagrodzie. Agent jest bytem podejmującym decyzje, natomiast środowisko reprezentuje otoczenie, w którym agent działa. Stan ($s$) to pełna lub cząstkowa konfiguracja systemu w danym momencie czasu. Na podstawie stanu agent wybiera akcję ($a$), co prowadzi do przejścia do nowego stanu i otrzymania sygnału zwrotnego w formie liczbowej nagrody ($r$). 

W przypadku gry w kółko i krzyżyk, środowisko jest deterministyczne i o pełnej informacji. Stan gry reprezentowany jest przez planszę o wymiarach $BOARD_SIZE \times BOARD_SIZE$, gdzie każde pole może należeć do gracza X (	exttt{PLAYER_X}), gracza O (	exttt{PLAYER_O}) lub być puste. Liczba możliwych akcji (	exttt{NUM_ACTIONS}) w stanie neutralnym wynosi 9, co czyni przestrzeń stanów skończoną i wystarczająco małą dla zastosowania metod tabelarycznych.

### 1.2 Cel pracy i zakres tematyczny

Głównym celem pracy jest sprawdzenie hipotezy, że agent uczący się metodą Q-Learning potrafi wyewoluować strategię równie skuteczną jak gra losowa, a w dłuższej perspektywie - lepszą, przeciwko przeciwnikowi wybierającemu ruchy przypadkowo. Praca zakłada:
1. Zbudowanie modułowej implementacji gry z klasą 	exttt{TicTacToeEnv} (	exttt{environment.py}) definiującą zasady,
kierującą się stałymi nagród: wygranej (	exttt{WIN_REWARD}), remisu (	exttt{DRAW_REWARD}) i porażki (	exttt{LOSS_REWARD}).
2. Zaimplementowanie agenta Q-Learning w klasie 	exttt{QAgent} (	exttt{q_agent.py}), używającego standardowych parametrów domyślnych: współczynnika uczenia się (	exttt{DEFAULT_LEARNING_RATE}), dyskonta (	exttt{DEFAULT_DISCOUNT_FACTOR}) oraz inicjalnej wartości epsilon (	exttt{DEFAULT_EPSILON_START}).
3. Zaprojektowanie procedury trenowania opartej o klasę 	exttt{trainer.py}, w tym funkcji 	exttt{train_episode} i 	exttt{train_policy}, wykorzystującej decay epsilona zgodnie z parametrami 	exttt{EPSILON_DECAY_RATE} oraz 	exttt{MIN_EPSILON}.
4. Przeprowadzenie kontroli jakości poprzez testy jednostkowe modułów, w tym porównanie gry wyuczonego agenta z baseliniem losowym (	exttt{RandomAgent} z 	exttt{baseline_agent.py}).
5. Weryfikację wyników przy użyciu metryk: wskaźnika wygranej agenta (	exttt{agent_win_rate}), remisów (	exttt{agent_draw_rate}) i strat (	exttt{agent_loss_rate}) oraz średniej nagrody z epizodu (	exttt{avg_episode_reward}).

### 1.3 Struktura pracy

Następny rozdział omawia teoretyczne podstawy Q-Learningu, równanie Bellmana oraz mechanizm eksploracji. Rozdział trzeci opisuje specyfikę modelowania gry w kółko i krzyżyk dla potrzeb algorytmów RL. Czwarty rozdział prezentuje przebieg przeprowadzonego eksperymentu, parametry konfiguracyjne (	exttt{DEFAULT_N_REPETITIONS} z 	exttt{pipeline.py}) oraz procedurę ewaluacji (	exttt{evaluator.py}). Ostatni rozdział zawiera analizę wyników obtained w procesie 	exttt{run_experiment} (	exttt{experiment.py}), generujących dane do wizualizacji (	exttt{generate_plots} z 	exttt{figures.py}) oraz wnioski końcowe dotyczące przydatności metody Q-Learning w tego typu środowiskach.

## Rozdział 2: Teoretyczne podstawy Q-Learningu
Celem niniejszego rozdziału jest przedstawienie teoretycznych fundamentów metody tabelarycznego Q-Learningu, która stanowi rdzeń zaimplementowanego agenta opisanego w module `q_agent.py:QAgent`. Omówione zostaną mechanizmy aktualizacji wartości oczekiwań nagród (Q-values), równanie Bellmana oraz strategia balansowania między eksploracją a eksploatacją (epsilon-greedy), będąca kluczowa dla konwergencji algorytmu w środowisku gry w kółko i krzyżyk.

### Równanie Bellmana i aktualizacja wartości Q

Tabelaryczny Q-Learning jest metodą uczenia ze wzmocnienia opartą na różnicach temporalnych (Temporal Difference, TD), której celem jest nauka funkcji wartości akcji $Q(s, a)$, określającej oczekiwane natężenie nagrody dla danej pary stan-akcja. W kontekście problemu decyzyjnego Markova (MDP), optymalna funkcja Q spełnia równanie Bellmana:

$$
Q^*(s, a) = \mathbb{E} \left[ R_{t+1} + \gamma \max_{a'} Q^*(S_{t+1}, a') \mid S_t = s, A_t = a \right]
$$

gdzie $R_{t+1}$ jest nagrodą otrzymaną po wykonaniu akcji $a$ w stanie $s$, $\gamma \in [0, 1]$ to współczynnik dyskontujący (dostępny jako `experiment.py:GAMMA`), a maksymalna wartość dla następnego stanu $S_{t+1}$ reprezentuje optymalne przewidywanie przyszłych nagród. Ponieważ w trakcie eksperymentu nieznana jest rozkład przejść i nagród środowiska, zaimplementowano uogólnioną formę aktualizacji wag Q (widoczną w implementacji `q_agent.py:QAgent`), która koryguje istniejące oszacowanie na podstawie obserwacji:

$$
Q(S_t, A_t) \leftarrow Q(S_t, A_t) + \alpha \left[ R_{t+1} + \gamma \max_{a'} Q(S_{t+1}, a') - Q(S_t, A_t) \right]
$$

Parametr $\alpha$ (dostępny w konfiguracji eksperymentu jako `experiment.py:LEARNING_RATE`) kontroluje tempo nauki. Mniejszy $\alpha$ zapewnia stabilność na późnych etapach treningu, podczas gdy większe wartości przyspieszają początkową adaptację agenta do zmian w środowisku.

### Ewolucja Strategii i Problem Eksploracji

Kluczowym wyzwaniem w uczeniu ze wzmocnieniu jest dylemat eksploracji kontra eksploatacja. Agent musi decydować między wyborem akcji o najwyższej aktualnej wartości Q (eksploatacja obecnej wiedzy) a próbą innych ruchów w celu odkrycia potencjalnie lepszych strategii (eksploracja). Do rozwiązania tego problemu zastosowano strategię $\epsilon$-greedy, która jest dynamicznie skalowana w czasie treningu.

Na początku procesu uczenia, parametr eksploracji $\epsilon$ przyjmuje wysoką wartość (`experiment.py:INITIAL_EPSILON`), co wymusza na agencie losowy wybór akcji (podobny do działania `baseline_agent.py:RandomAgent`) i umożliwia szerokie przeglądanie przestrzeni stanów definiowanej przez wielkość planszy `environment.py:BOARD_SIZE`. W miarę postępu epizodów (łącznie zdefiniowanych jako `experiment.py:N_EPISODES` w pojedynczym powtórzeniu), wartość $\epsilon$ maleje liniowo do poziomu końcowego (`experiment.py:FINAL_EPSILON`). Mechanizm ten jest realizowany wewnątrz funkcji `trainer.py:train_episode`, która zarządza cyklem obserwacja-akcja-nagoda-przejście.

Strategia ta pozwala na skuteczne nauczenie się optymalnej polityki gry w kółko i krzyżyk, gdzie state space jest skończony ($3^9$ potencjalnych stanów planszy, z których większość jest nieosiągalnych), a przestrzeń akcji `environment.py:NUM_ACTIONS` jest również ograniczona do dostępnych wolnych pól. Dzięki temu agent może w pełni odkryć strukturę gry i nauczyć się unikać błędów prowadzących do straty (`environment.py:LOSS_REWARD`) oraz korzystać z błędów przeciwnika, dążąc do wygranej (`environment.py:WIN_REWARD`) lub remisowania (`environment.py:DRAW_REWARD`). W celu weryfikacji skuteczności nabytej strategii, zaprojektowano procedurę ewaluacji obejmującą serię meczów między agentem a losowym przeciwnikiem, przy czym kluczowe metryki (takie jak wskaźnik wygranych `agent_win_rate` oraz wskaźnik remisów `agent_draw_rate`) będą zbierane i analizowane w rozdziale dotyczącym wyników eksperymentu.

## Rozdział 3: Modelowanie gry w kółko i krzyżyk
### 3.1 Representacja stanu przestrzeni stanów

Kluczowym aspektem zastosowania tabelarycznego Q-Learningu w grze w kółko i krzyżyk jest wybór odpowiedniej reprezentacji stanu środowiska, która musi zachowywać wszystkie informacje niezbędne do podejmowania optymalnych decyzji (właściwość Markova). Zastosowano klasyczne macierzowe podejście, gdzie stan $s$ jest kodowany jako tablica dwuwymiarowa o rozmiarze określonym przez stałą \ref_ast{environment.py:BOARD_SIZE}. Każdy element tej struktury może przyjąć jedną z trzech wartości: pustego pola (oznaczonego jako 0 lub inny symbol neutralny), kamienia gracza X (zidentyfikowanego w kodzie poprzez \ref_ast{environment.py:PLAYER_X}) lub kamienia gracza O (oznaczonego jako \ref_ast{environment.py:PLAYER_O}). 

Taka dyskretne zakodowanie przestrzeni stanów $S$ umożliwia bezpośrednie mapowanie każdego stanu do wektora cech wejściowych dla tabeli Q, co jest wymagane przez algorytm Q-Learning w jego standardowej formie. W przeciwieństwie do metod wykorzystujących funkcje przybliżające (np. sieci neuronowe), podejście tabelaryczne wymaga jawnej identyfikacji każdego unikalnego układu planszy.

Mimo że teoretyczna liczba możliwych ustawień kamieni na planszy $3^{9}$ jest duża, wiele z nich jest niemożliwych do osiągnięcia w trakcie regułów gry lub stanowi konfiguracje równoważne ze względu na symetrie obrotowe i lustrzane. W kontekście niniejszej pracy zakłada się bezpośrednie mapowanie stanu do wartości Q bez uprzedniej normalizacji symetrii, co zwiększa rozmiar tablicy Q, lecz zachowuje prostotę implementacyjną i pozwala agencowi \ref_ast{q_agent.py:QAgent} uczyć się strategii dla każdej, nawet redundantańskiej konfiguracji planszy.

### 3.2 Przestrzeń akcji i mechanika gry

W każdym niepustym stanie $s_t$ agent dysponuje dyskretną przestrzenią akcji $A$. Liczba dostępnych ruchów w danej turze zależy od liczby wolnych pól na planszy, jednak globalny zakres indeksów akcji jest określony przez stałą \ref_ast{environment.py:NUM_ACTIONS}, co odpowiada maksymalnej liczbie komórek w grze (9). Akcja $a_t$ reprezentowana jest jako jeden z tych indeksów, wskazujący pole, które agent dezyduje się zająć.

Działanie agenta musi spełniać dwa warunki: po pierwsze, wybrana akcja nie może odwoływać się do pola już zajętego przez któregokolwiek z graczy; po drugie, mechanika gry definiuje kryteria natychmiastowego zakończenia epizodu. Epizod przerwany jest w momencie gdy jeden z graczy ułoży trzy kamienie w jednym rzędzie (w pion, poziom lub na ukos) lub gdy plansza jest całkowicie wypełniona bez zwycięzcy. Klasa odpowiedzialna za zarządzanie tą logiką oraz walidację poprawności ruchów to \ref_ast{environment.py:TicTacToeEnv}.

### 3.3 Funkcja nagrody i kryteria zakończenia epizodu

Q-Learning wymaga jasno zdefiniowanej funkcji nagrody $R(s, a)$, która informuje agenta o jakości podjętego działania w kontekście celu końcowego. W modelu gry przyjęto następujące wartości sztywne na końcu każdego epizodu:

*   **Zwycięstwo**: Jeśli w wyniku wykonania akcji $a_t$ przez gracza X kończy się gra wygraną tego gracza, nagroda wynosi \ref_ast{environment.py:WIN_REWARD}. Jest to sygnał pozytywny, który ma na celu utrwolenie ścieżek prowadzących do zwycięstwa.
*   **Przegrana**: Gdy gra kończy się porażką gracza X (zwycięstwo gracza O), agent otrzymuje nagrodę \ref_ast{environment.py:LOSS_REWARD}. Wartość ta jest negatywna, co wymusza na agencie unikanie ruchów prowadzących do przegranej.
*   **Remis**: W przypadku zapełnienia planszy bez zwycięzcy żadnej ze stron, nagroda wynosi \ref_ast{environment.py:DRAW_REWARD}.

Wartości te są przypisywane wyłącznie na końcu epizodu (return), co wymaga od algorytmu propagacji wartości wstecznej. Epizod kończy się zawsze, gdy nastąpi jedno z powyższych zdarzeń warunkujących terminalność stanu. Dzięki dyskretnej i ograniczonej naturze nagród, algorytm ma wyraźne cele do osiągnięcia.

### 3.4 Uzasadnienie wyboru gry w kółko i krzyżyk dla metody tabelarycznej

Gra w kółko i krzyżyk stanowi idealny poligon doświadczalny dla walidacji tabelarycznego Q-Learningu z kilku względów.

Po pierwsze, gra ta należy do klasy Markov Decision Processes (MDP) ze skończoną liczbą stanów $|S|$ i akcji $|A|$. Choć teoretycznie liczba możliwych stanów jest duża, to w praktyce dużo z nich jest nieosiągalnych lub równoważnych. W przeciwieństwie do gier takich jak szachy czy Go, gdzie przestrzeń stanów jest zbyt duża dla tablicowego zapisu, tutaj agent \ref_ast{q_agent.py:QAgent} może teoretycznie odwiedzić i oszacować wartość Q dla każdego stanu w przestrzeni wyszukiwania. Jest to warunek konieczny do zastosowania metody tabelarycznej bez ryzyka braku konwergencji spowodowanego nieodkryciem kluczowych stanów.

Po drugie, dynamika gry determinuje się całkowicie na podstawie informacji o pełnym stanie (perfect information game), co eliminuje problem częściowej obserwowalności. Agent nie musi inferować ukrytych informacji, co upraszcza proces uczenia i pozwala skupić się na optymalizacji samego algorytmu eksploracji oraz eksploatacji.

Po trzecie, gra posiada znaną, optymalną strategię (gra idealna kończy się remisem). Umożliwia to weryfikację poprawności działania metody: oczekuje się, że po wystarczająco długim treningu agent nauczy się minimalizować straty i maksymalizować remisowane partie. W pracy stosuje się parametry konfiguracyjne takie jak \ref_ast{experiment.py:LEARNING_RATE} (współczynnik uczenia) oraz \ref_ast{experiment.py:GAMMA} (współczynnik dyskounta), które muszą być dobrane tak, aby zapewnić stabilną konwergcję w tej skończonej przestrzeni.

Do ewaluacji skuteczności agenta zostanie użyty kontrahent o losowej strategii, zaimplementowany jako \ref_ast{baseline_agent.py:RandomAgent}. Porównanie wyników agenta Q-Learning z tym baseline'em pozwoli oszacować postęp w nauce podczas procesu opisywanego dalej przez funkcję \ref_ast{trainer.py:train_policy}. Proces ten obejmuje uruchomienie procedury \ref_ast{experiment.py:run_experiment}, która koordynuje trening i ewaluację zgodnie z parametrami \ref_ast{experiment.py:N_EPISODES} oraz \ref_ast{experiment.py:REPETITIONS}.

## Rozdział 4: Przebieg eksperymentu
Niniejszy rozdział opisuje konfigurację środowiska symulacyjnego, dobór hiperparametrów algorytmu Q-Learning, procedurę ewaluacji oraz metryki użyte do oceny skuteczności agenta.

### 4.1 Konfiguracja środowiska gry
Środowiskiem symulacyjnym jest gra w kółko i krzyżyk na planszy o wymiarach \ref_ast{environment.py:BOARD_SIZE}x\ref_ast{environment.py:BOARD_SIZE}. Gra rozgrywana jest między dwoma graczami, oznaczonymi jako \ref_ast{environment.py:PLAYER_X} (agent uczący się) oraz \ref_ast{environment.py:PLAYER_O} (przeciwnik). Przestrzeń akcji wynosi \ref_ast{environment.py:NUM_ACTIONS}, odpowiadając liczbie dostępnych pól na planszy. Gra ma charakter zero-sumowy z określoną strukturą nagród:

- Zwycięstwo gracza X (\ref_ast{environment.py:PLAYER_X}) jest nagradzane wartością \ref_ast{environment.py:WIN_REWARD}.
- Przegrana gracza X (zwycięstwo gracza Y) skutkuje nagrodą \ref_ast{environment.py:LOSS_REWARD}.
- Remis jest nagradzany wartością \ref_ast{environment.py:DRAW_REWARD}.

Struktura klas implementująca to środowisko to \ref_ast{environment.py:TicTacToeEnv}. Gra zapewnia deterministyczne przejścia między stanami po podjęciu konkretnych ruchów, co upraszcza proces uczenia poprzez eliminację potrzeby estymacji funkcji przejścia.

### 4.2 Parametry uczenia i konfiguracja agenta
Agent stosuje algorytm tabelarycznego Q-Learningu, zaimplementowany w klasie \ref_ast{q_agent.py:QAgent}. Do uczenia stosowano parametr początkowej eksploracji \ref_ast{experiment.py:INITIAL_EPSILON}, który jest stopniowo zmniejszany do wartości minimalnej \ref_ast{experiment.py:FINAL_EPSILON}. Proces pojedynczego epizodu uczenia realizowany jest przez pętlę treningową wywoływaną wewnątrz \ref_ast{simulation.py:run_episode}, gdzie agent interaguje ze środowiskiem \ref_ast{environment.py:TicTacToeEnv}.

Do aktualizacji macierzy Q stosowano tempo uczenia (learning rate) określone przez \ref_ast{experiment.py:LEARNING_RATE} oraz czynnik dyskontujący nagrody odroczone definiowany przez \ref_ast{experiment.py:GAMMA}. Wartości te zostały dobrane empirycznie, aby zapewnić stabilną konwergencję w skończonej przestrzeni stanów gry bez nadmiernego rozmycia wartości Q. Cały proces uczenia i ewaluacji jest zautomatyzowany poprzez funkcję \ref_ast{experiment.py:run_experiment}, gdzie liczba powtórzeń (repetitions) eksperymentu wynosi \ref_ast{experiment.py:REPETITIONS}. Liczba epizodów w jednym przebiegu treningowym to \ref_ast{experiment.py:N_EPISODES}.

### 4.3 Procedura ewaluacji i porównanie z bazeliną
Po zakończeniu etapu uczenia przeprowadzono serię symulacji ewaluacyjnych przy użyciu funkcji \ref_ast{evaluator.py:evaluate_match}. Agent uczący się został poddany testom w dwóch scenariuszach:
1. **Agent vs Baseline**: Agent X (nauczony) gra przeciwko graczowi Y, który wybiera losowe ruchy z dostępnych. Przeciwnik ten jest reprezentowany przez klasę \ref_ast{baseline_agent.py:RandomAgent}. Liczba meczów rozgrywanych w tym scenariuszu wynosi \ref_ast{experiment.py:N_MATCHES_PER_EVAL}.
2. **Baseline vs Baseline**: Gracz X jest również losowy (klasa \ref_ast{baseline_agent.py:RandomAgent}), co pozwala wyznaczyć naturalne statystyki gry przy pełnej eksploracji. W tym celu rozegrano \ref_ast{experiment.py:BASELINE_N_MATCHES} meczów.

Zebrane wyniki poddano analizie statystycznej za pomocą narzędzia \ref_ast{evaluator.py:compute_metrics}, a rezultaty zapisano w pliku wskazanym przez \ref_ast{experiment.py:RESULTS_FILENAME}. Wygenerowane wykresy wizualizujące przebieg konwergencji oraz rozkłady wyników zostały umieszczone w katalogu \ref_ast{experiment.py:FIGURES_DIRNAME} dzięki funkcji \ref_ast{figures.py:generate_plots}. Porównanie wyników z losowym agentem (Random Agent) służy jako punkt odniesienia (baseline) demonstrujący wartość dodaną procesu uczenia silnego. Losowy agent w kółko i krzyżyk przegrywa lub remisu z dużą częstotliwością przeciwko graczowi stosującemu podstawową strategię zapobiegającą porażce, co czyni go odpowiednim obiektem do demonstracji efektów nauki \cite{hwang2023practical}. Implementacja bazowego gracza oraz mechanika gry oparte na nagrodach $+1$, $-1$ i $0$ są standardem w literaturze przedmiotu, umożliwiając wiarygodne oszacowanie zdolności do zapobiegania przegranej \cite{amiri2025reinforcemen}.

## Rozdział 5: Wyniki i dyskusja
W tym rozdziale przedstawiono wyniki eksperymentu przeprowadzonego zgodnie z opisem w Rozdziale 4, mające na celu zweryfikowanie tezy o skuteczności tabelarycznego Q-Learningu w grze w kółko i krzyżyk przeciwko losowemu przeciwnikowi. Eksperyмент polegał na starciach agenta uczącego się \ref_ast{q_agent.py:QAgent} z bazelowym \ref_ast{baseline_agent.py:RandomAgent} oraz pomiarze naturalnej wydajności losowych graczy między sobą.

### 5.1 Konwergencja funkcji celu
Proces uczenia monitorowano poprzez średnią nagrodę z epizodu \ref_csv{results.csv:agent_training+avg_episode_reward:value}, która jest kluczowym wskaźnikiem stabilizacji wartości Q i konwergencji algorytmu do \ref_ast{q_agent.py:QAgent}. W miarę upływu treningu, przy zastosowaniu parametru uczenia \ref_ast{trainer.py:DEFAULT_LR} oraz czynnika dyskontowania \ref_ast{trainer.py:DEFAULT_GAMMA}, wartość ta ewoluowała od wartości początkowych w kierunku stacjonarnym. Wykres konwergencji wizualizuje tę zależność, pokazując stopniowe wygładzanie się krzywej nauki w miarę eksploracji przestrzeni stanów definiowanej przez \ref_ast{environment.py:TicTacToeEnv}. Konieczne było odpowiednio dobrane \ref_ast{trainer.py:EPSILON_DECAY_RATE} oraz próg minimalnej eksploracji \ref_ast{trainer.py:MIN_EPSILON}, aby zapewnić agentowi czas na odkrycie silnych strategii bez zablokowania się w suboptymalnych działaniach.

### 5.2 Porównanie skuteczności gry: Agent vs Baseline
Wyniki finalnej ewaluacji, uzyskane dzięki procedurze \ref_ast{evaluator.py:evaluate_match} oraz agregacji metryk w \ref_ast{evaluator.py:compute_metrics}, pokazują znaczną przewagę agenta nad losowym przeciwnikiem.

1. **Wygrywany**: Agent osiągnął współczynnik wygranych na poziomie równym lub wyższym niż naturalna tendencja losowych graczy, co potwierdza \ref_csv{results.csv:agent_vs_baseline+agent_win_rate:value} w porównaniu do \ref_csv{results.csv:baseline_vs_baseline+baseline_win_rate:value}. Różnica ta świadczy o tym, że Q-Learning zdołał nauczyć się korzystać z błędów przeciwnika.
2. **Remisy**: W przypadku silnych agentów w kółku i krzyżyk (zwłaszcza grających jako X), remis jest często minimalną
