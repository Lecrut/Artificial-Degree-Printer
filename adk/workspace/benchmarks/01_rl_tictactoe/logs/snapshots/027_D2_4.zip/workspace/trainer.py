"""Manages the training loop for a Q-Learning agent against a random baseline environment."""
import numpy as np
from typing import Tuple, Dict, Any, List
from environment import TicTacToeEnv
from q_agent import QAgent
DEFAULT_LR: float = 0.1
DEFAULT_GAMMA: float = 0.99
EPSILON_DECAY_RATE: float = 0.995
MIN_EPSILON: float = 0.01

def train_episode(env: TicTacToeEnv, q_agent: QAgent, epsilon: float, seed: int=None) -> Tuple[float, int]:
    """Runs a single episode of Tic-Tac-Toe between the Q-Agent and a Random Agent.

    Args:
        env: The Gymnasium-compatible environment instance, expected to be already reset or reset within this function if state is None.
        q_agent: The Q-Learning agent being trained.
        epsilon: Current exploration rate for the epsilon-greedy policy.
        seed: Optional seed for initializing the internal RandomAgent. If provided, ensures deterministic baseline moves.

    Returns:
        tuple: (total_reward, num_steps)
            - total_reward: Sum of rewards received by the Q-Agent during the episode.
            - num_steps: Number of steps taken until termination.

    Raises:
        ValueError: If an invalid action is selected or if the environment state becomes inconsistent."""
    from baseline_agent import RandomAgent
    obs, _ = env.reset(seed)
    done = False
    truncated = False
    total_reward = 0.0
    step_count = 0
    opponent = RandomAgent(seed) if seed is not None else RandomAgent(None)
    while not (done or truncated):
        moves = env.get_valid_moves()
        action = q_agent.choose_action(env.get_state_hash(env.state), moves)
        next_obs, reward, done, truncated, _ = env.step(action)
        total_reward += reward
        next_state_hash = env.get_state_hash(next_obs) if isinstance(next_obs, np.ndarray) else next_obs
        q_agent.update(env.get_state_hash(obs), action, reward, next_state_hash, done)
        obs = next_obs
        step_count += 1
    return (total_reward, step_count)

def train_policy(n_episodes: int, env_seed: int=None) -> Dict[str, Any]:
    """Trains the Q-Agent for a specified number of episodes against a Random Baseline.

    Args:
        n_episodes: Total number of training episodes to run.
        env_seed: Optional seed for initializing the environment. Ensures reproducibility of game outcomes.

    Returns:
        dict: Training statistics containing:
            - 'rewards' (list[float]): List of total rewards per episode.
            - 'avg_reward_window' (float): Moving average of the last 100 episodes (0.0 if less than 100 episodes).
            - 'final_epsilon' (float): The value of epsilon after training."""
    env = TicTacToeEnv()
    agent = QAgent(n_actions=9, lr=DEFAULT_LR, gamma=DEFAULT_GAMMA)
    reward_history: List[float] = []
    epsilon = 1.0
    window_size = 100
    for i in range(n_episodes):
        current_epsilon = max(MIN_EPSILON, epsilon * EPSILON_DECAY_RATE)
        seed = env_seed + i if env_seed is not None else None
        reward, _ = train_episode(env, agent, current_epsilon, seed)
        reward_history.append(reward)
        epsilon = current_epsilon
    final_epsilon = max(MIN_EPSILON, epsilon * EPSILON_DECAY_RATE)
    avg_reward_window = 0.0
    if len(reward_history) >= window_size:
        avg_reward_window = np.mean(reward_history[-window_size:])
    stats: Dict[str, Any] = {'rewards': reward_history, 'avg_reward_window': avg_reward_window, 'final_epsilon': final_epsilon}
    return stats
