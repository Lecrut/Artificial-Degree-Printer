"""Implements a random baseline player for Tic-Tac-Toe that selects uniformly from valid moves."""
from typing import Optional, List
import random

class RandomAgent:
    """A simple agent that chooses a legal move uniformly at random."""
    _rng: random.Random

    def __init__(self, seed: Optional[int]=None) -> None:
        """Initializes the RandomAgent with a specified random number generator."""
        self._rng = np.random.default_rng(seed)

    def choose_action(self, env: TicTacToeEnv) -> int:
        """Selects one action from the allowed moves in the environment.

        Args:
            env: The Gymnasium environment instance providing the current state and valid moves via `get_valid_moves()`.

        Returns:
            int: A single action index chosen uniformly at random from the valid moves. If no moves are available, raises ValueError."""
        possible_moves = env.get_valid_moves()
        if not possible_moves:
            raise ValueError('Possible moves list cannot be empty')
        return possible_moves[int(self._rng.choice(len(possible_moves)))]

def compute_self_play_stats(n_matches: int, seed: int) -> dict:
    """Runs a series of self-play matches between two independent RandomAgents to establish a baseline against the TicTacToeEnv.

    Args:
        n_matches: Number of full games to play.
        seed: Seed for the random number generator to ensure reproducibility.

    Returns:
        dict: Statistics with keys 'p1_win_rate', 'p2_win_rate', 'draw_rate'. All rates are in [0, 1]."""
    p1_wins = 0
    p2_wins = 0
    draws = 0
    if n_matches == 0:
        return {'p1_win_rate': 0.0, 'p2_win_rate': 0.0, 'draw_rate': 0.0}
    for i in range(n_matches):
        match_seed = seed + i + 1
        agent_p1 = RandomAgent(seed=match_seed)
        agent_p2 = RandomAgent(seed=match_seed * 13)
        env = TicTacToeEnv()
        obs, _ = env.reset(seed=match_seed)
        terminated = False
        while not terminated:
            valid_moves = env.get_valid_moves()
            if not valid_moves:
                break
            action_p1 = agent_p1.choose_action(env)
            obs, _, terminated, _, info = env.step(action_p1)
            if terminated:
                winner = info.get('winner', 0)
                if winner == PLAYER_X:
                    p1_wins += 1
                elif winner == PLAYER_O:
                    p2_wins += 1
                else:
                    draws += 1
                break
            action_p2 = agent_p2.choose_action(env)
            obs, _, terminated, _, info = env.step(action_p2)
            if terminated:
                winner = info.get('winner', 0)
                if winner == PLAYER_X:
                    p1_wins += 1
                elif winner == PLAYER_O:
                    p2_wins += 1
                else:
                    draws += 1
                break
    total = p1_wins + p2_wins + draws
    return {'p1_win_rate': p1_wins / total if total > 0 else 0.0, 'p2_win_rate': p2_wins / total if total > 0 else 0.0, 'draw_rate': draws / total if total > 0 else 0.0}
