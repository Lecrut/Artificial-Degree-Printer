"""Implements a tabular Q-Learning agent with configurable epsilon-greedy exploration for Tic-Tac-Toe."""
import numpy as np
from typing import List
DEFAULT_LEARNING_RATE: float = 0.1
DEFAULT_DISCOUNT_FACTOR: float = 0.99
DEFAULT_EPSILON_START: float = 1.0

class QAgent:
    """A tabular Q-Learning agent that maintains a Q-table indexed by state hashes."""
    q_table: np.ndarray
    n_actions: int

    def __init__(self, n_states: int, n_actions: int, lr: float=DEFAULT_LEARNING_RATE, gamma: float=DEFAULT_DISCOUNT_FACTOR, epsilon: float=DEFAULT_EPSILON_START) -> None:
        """Initializes the Q-agent with a zero-initialized Q-table and specified hyperparameters."""
        self.q_table = np.zeros((n_states, n_actions), dtype=np.float64)
        self.n_actions: int = n_actions
        self.lr: float = lr
        self.gamma: float = gamma
        self.epsilon: float = epsilon

    def choose_action(self, state_hash: int, possible_moves: List[int]) -> int:
        """Selects an action using the agent's internal epsilon-greedy policy."""
        if np.random.rand() < self.epsilon:
            return int(np.random.choice(possible_moves))
        else:
            q_values = self.q_table[state_hash][possible_moves]
            max_q = np.max(q_values)
            best_moves = [move for move, q in zip(possible_moves, q_values) if q == max_q]
            return int(np.random.choice(best_moves))

    def update(self, state_hash: int, action: int, reward: float, next_state_hash: int, done: bool) -> None:
        """Updates the Q-table entry for the given state and action using the Bellman equation with internal hyperparameters."""
        current_size = self.q_table.shape[0]
        if state_hash >= current_size:
            new_rows = state_hash - current_size + 1
            padding = np.zeros((new_rows, self.n_actions), dtype=np.float64)
            self.q_table = np.vstack([self.q_table, padding])
        if next_state_hash >= self.q_table.shape[0]:
            new_rows = next_state_hash - self.q_table.shape[0] + 1
            padding = np.zeros((new_rows, self.n_actions), dtype=np.float64)
            self.q_table = np.vstack([self.q_table, padding])
        current_q = self.q_table[state_hash, action]
        if done:
            max_future_q = 0.0
        else:
            max_future_q = np.max(self.q_table[next_state_hash])
        new_q = current_q + self.lr * (reward + self.gamma * max_future_q - current_q)
        self.q_table[state_hash, action] = new_q

    def save_q_table(self, filepath: str) -> None:
        """Saves the Q-table to a binary file (.npy). Args: filepath - The path where the file will be saved."""
        np.save(filepath, self.q_table)

    def load_q_table(self, filepath: str) -> None:
        """Loads a Q-table from a binary file (.npy) into the agent's q_table attribute. Overwrites existing values. Args: filepath - The path to the file to load. Raises FileNotFoundError if the file does not exist."""
        import os
        if not os.path.exists(filepath):
            raise FileNotFoundError(f'Q-table file not found: {filepath}')
        self.q_table = np.load(filepath)
