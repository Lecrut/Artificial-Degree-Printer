"""Tests for QAgent from q_agent module."""
import numpy as np
import pytest
import os
from q_agent import QAgent

class TestQAgentInit:

    def test_q_table_initialized_correct_shape(self):
        """Test that q_table is a numpy array with shape (n_states, n_actions) initialized to zeros."""
        agent = QAgent(n_states=10, n_actions=9)
        assert isinstance(agent.q_table, np.ndarray)
        assert agent.q_table.shape == (10, 9)
        assert np.all(agent.q_table == 0)

    def test_n_actions_attribute(self):
        """Test that n_actions attribute is set correctly."""
        agent = QAgent(n_states=10, n_actions=5)
        assert agent.n_actions == 5

    def test_default_hyperparameters(self):
        """Test that default hyperparameters are used if not provided."""
        agent = QAgent(n_states=10, n_actions=9)
        assert agent.lr == 0.1
        assert agent.gamma == 0.9
        assert agent.epsilon == 1.0

    def test_custom_hyperparameters(self):
        """Test that custom hyperparameters are stored correctly."""
        agent = QAgent(n_states=10, n_actions=9, lr=0.2, gamma=0.85, epsilon=0.5)
        assert agent.lr == 0.2
        assert agent.gamma == 0.85
        assert agent.epsilon == 0.5

class TestChooseAction:

    def test_choose_action_returns_valid_move(self):
        """Test that choose_action returns a move present in possible_moves."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        possible_moves = [1, 4, 7]
        action = agent.choose_action(state_hash, possible_moves)
        assert action in possible_moves

    def test_choose_action_exploration_returns_valid_move(self):
        """Test that when epsilon=1.0 (full exploration), action is still valid."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        possible_moves = [2]
        action = agent.choose_action(state_hash, possible_moves)
        assert action in possible_moves

    def test_choose_action_deterministic_with_zero_q_values(self):
        """Test that with zero Q-values and epsilon=0 (exploitation), any valid move is acceptable."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        possible_moves = [1, 2]
        action = agent.choose_action(state_hash, possible_moves)
        assert action in possible_moves

    def test_choose_action_with_high_q_value(self):
        """Test that when one move has a significantly higher Q-value, it is chosen with epsilon=0."""
        agent = QAgent(n_states=10, n_actions=9, epsilon=0)
        state_hash = 0
        agent.q_table[state_hash, 1] = 10.0
        possible_moves = [0, 1]
        action = agent.choose_action(state_hash, possible_moves)
        assert action == 1

    def test_choose_action_with_high_q_value_other_move(self):
        """Test that when action 0 has a higher Q-value, it is chosen."""
        agent = QAgent(n_states=10, n_actions=9, epsilon=0)
        state_hash = 0
        agent.q_table[state_hash, 0] = 10.0
        possible_moves = [0, 1]
        action = agent.choose_action(state_hash, possible_moves)
        assert action == 0

    def test_choose_action_exploration_range(self):
        """Test that actions are chosen within the range of n_actions."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        possible_moves = list(range(9))
        action = agent.choose_action(state_hash, possible_moves)
        assert 0 <= action < 9

    def test_choose_action_empty_possible_moves_raises(self):
        """Test that choose_action raises ValueError if possible_moves is empty."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        with pytest.raises(ValueError):
            agent.choose_action(state_hash, [])

    def test_choose_action_invalid_move_raises(self):
        """Test that choose_action raises ValueError if possible_moves contains invalid actions."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        # Note: This test assumes the implementation validates moves against n_actions.
        # If the implementation does not validate, this test will fail (DID NOT RAISE).
        # We keep the intent to test validity checking as per specification/contract expectations.
        with pytest.raises(ValueError):
            agent.choose_action(state_hash, [9, 10])

class TestUpdate:

    def test_update_modifies_q_table(self):
        """Test that update method modifies the q_table entry."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        action = 1
        reward = 1.0
        next_state_hash = 1
        done = False
        initial_q_value = agent.q_table[state_hash, action].item()
        agent.update(state_hash, action, reward, next_state_hash, done)
        updated_q_value = agent.q_table[state_hash, action]
        assert not np.isclose(initial_q_value, updated_q_value.item())

    def test_update_with_done_true(self):
        """Test update when done=True (no future value term)."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        action = 1
        reward = 5.0
        next_state_hash = 2
        done = True
        agent.update(state_hash, action, reward, next_state_hash, done)
        assert np.isclose(agent.q_table[state_hash, action].item(), 0.5)

    def test_update_with_done_false(self):
        """Test update when done=False (future value term included)."""
        agent = QAgent(n_states=10, n_actions=9)
        next_state_hash = 5
        agent.q_table[next_state_hash, 2] = 3.0
        state_hash = 0
        action = 1
        reward = 1.0
        done = False
        agent.update(state_hash, action, reward, next_state_hash, done)
        assert np.isclose(agent.q_table[state_hash, action].item(), 0.397)

    def test_update_updates_lr_and_gamma(self):
        """Test that update uses current lr and gamma attributes."""
        agent = QAgent(n_states=10, n_actions=9, lr=0.5, gamma=0.5)
        state_hash = 0
        action = 1
        reward = 10.0
        next_state_hash = 2
        done = True
        agent.update(state_hash, action, reward, next_state_hash, done)
        assert np.isclose(agent.q_table[state_hash, action].item(), 5.0)

class TestSaveLoad:

    def test_save_q_table_creates_file(self, tmp_path):
        """Test that save_q_table creates a file at the specified path."""
        agent = QAgent(n_states=10, n_actions=9)
        filepath = str(tmp_path / 'test_q_table.npy')
        agent.save_q_table(filepath)
        assert os.path.exists(filepath)

    def test_save_and_load_q_table(self, tmp_path):
        """Test that loading the saved Q-table restores its values."""
        agent1 = QAgent(n_states=10, n_actions=9)
        agent1.q_table[0, 1] = 5.0
        agent1.q_table[2, 3] = 2.5
        filepath = str(tmp_path / 'test_q_table.npy')
        agent1.save_q_table(filepath)
        agent2 = QAgent(n_states=10, n_actions=9)
        agent2.load_q_table(filepath)
        assert np.array_equal(agent1.q_table, agent2.q_table)

    def test_load_q_table_file_not_found(self):
        """Test that load_q_table raises FileNotFoundError for non-existent file."""
        agent = QAgent(n_states=10, n_actions=9)
        with pytest.raises(FileNotFoundError):
            agent.load_q_table('non_existent_path.npy')

    def test_save_load_preserves_shape(self, tmp_path):
        """Test that saved and loaded Q-table has correct shape."""
        n_states = 15
        n_actions = 7
        agent = QAgent(n_states=n_states, n_actions=n_actions)
        filepath = str(tmp_path / 'test_shape.npy')
        agent.save_q_table(filepath)
        loaded_agent = QAgent(n_states=1, n_actions=1)
        loaded_agent.load_q_table(filepath)
        assert loaded_agent.q_table.shape == (n_states, n_actions)