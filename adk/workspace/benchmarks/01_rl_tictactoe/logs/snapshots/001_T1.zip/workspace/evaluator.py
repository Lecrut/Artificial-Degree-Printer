"""Provides evaluation utilities for Tic-Tac-Toe agents, including match simulation and metric computation."""
import numpy as np
from typing import Dict, Any, Optional, List, Tuple
from environment import TicTacToeEnv, WIN_REWARD, LOSS_REWARD, DRAW_REWARD
from q_agent import QAgent
from baseline_agent import RandomAgent

def evaluate_match(agent_a: Any, agent_b: Any, env_template: TicTacToeEnv, n_matches: int, epsilon: float) -> Dict[str, int]:
    """Simulates a series of matches between two agents and returns the result counts. The agents take turns as Player X (first mover) and Player O (second mover) across the specified number of matches to balance advantage. For `QAgent` instances, this function passes `epsilon` during action selection to control exploration levels during evaluation. Returns a dictionary with keys 'wins_agent_a' (int), 'wins_agent_b' (int), and 'draws' (int). The sum of these values will be equal to `n_matches` unless an exception occurs. If an agent raises an exception during play, that match is not counted in totals but does not stop execution. Handles edge cases such as n_matches=0 (returns all zeros)."""
    raise NotImplementedError

def compute_metrics(win_rate: float, win_count: int, draw_count: int, loss_count: int, n_matches: int, baseline_win_rate: float=0.0, baseline_draw_rate: float=0.0) -> Dict[str, float]:
    """Computes performance metrics from raw match counts and rates. Returns a dictionary containing 'agent_win_rate' (float in [0, 1], the proportion of wins for the evaluated agent), 'agent_draw_rate' (float in [0, 1]), 'agent_loss_rate' (float in [0, 1]), 'vs_baseline_advantage' (float, calculated as agent_win_rate - baseline_win_rate), and 'vs_baseline_draw_advantage' (float, calculated as agent_draw_rate - baseline_draw_rate). Handles edge cases where n_matches is 0 by returning zero rates. The rates are normalized such that win + draw + loss <= 1."""
    raise NotImplementedError
