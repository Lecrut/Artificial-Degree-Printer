"""Implements a tabular Q-Learning agent with configurable epsilon-greedy exploration for Tic-Tac-Toe."""
import numpy as np
from typing import List
DEFAULT_LEARNING_RATE: float = 0.1
DEFAULT_DISCOUNT_FACTOR: float = 0.99
DEFAULT_EPSILON_START: float = 1.0

class QAgent:
    """A tabular Q-Learning agent that maintains a Q-table indexed by state hashes."""
    q_table: np.ndarray
    n_actions: int

    def __init__(self, n_states: int, n_actions: int) -> None:
        """Initializes the Q-agent with a zero-initialized Q-table. Args: n_states - The total number of possible states (hashes) for indexing the table. n_actions - The number of possible actions (9). Sets internal hyperparameters to default values."""
        raise NotImplementedError

    def choose_action(self, state_hash: int, possible_moves: List[int], epsilon: float) -> int:
        """Selects an action using an epsilon-greedy policy. If a random number is less than epsilon, chooses uniformly among available moves (exploration). Otherwise, chooses the move with the highest Q-value for the given state_hash; ties are broken randomly among the available moves (exploitation). Args: state_hash - The integer identifier of the current state. possible_moves - A list of integers representing valid actions in this state. epsilon - The probability of exploration. Returns: The selected action as an integer."""
        raise NotImplementedError

    def update(self, state_hash: int, action: int, reward: float, next_state_hash: int, done: bool, lr: float, gamma: float) -> None:
        """Updates the Q-table entry for the given state and action using the Bellman equation. The update rule is: Q(s,a) <- Q(s,a) + lr * (reward + gamma * max(Q(next_s)) - Q(s,a)). If 'done' is True, the future value term is zeroed. Args: state_hash - The integer identifier of the current state. action - The integer action taken. reward - The immediate reward received. next_state_hash - The integer identifier of the next state. done - Boolean indicating if the episode has terminated. lr - The learning rate. gamma - The discount factor."""
        raise NotImplementedError

    def save_q_table(self, filepath: str) -> None:
        """Saves the Q-table to a binary file (.npy). Args: filepath - The path where the file will be saved."""
        raise NotImplementedError

    def load_q_table(self, filepath: str) -> None:
        """Loads a Q-table from a binary file (.npy) into the agent's q_table attribute. Overwrites existing values. Args: filepath - The path to the file to load. Raises FileNotFoundError if the file does not exist."""
        raise NotImplementedError
