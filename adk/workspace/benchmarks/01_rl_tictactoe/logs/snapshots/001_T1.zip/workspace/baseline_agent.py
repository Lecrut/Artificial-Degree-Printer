"""Implements a random baseline player for Tic-Tac-Toe that selects uniformly from valid moves."""
from typing import Optional, List
import random

class RandomAgent:
    """A simple agent that chooses a legal move uniformly at random."""
    _rng: random.Random

    def __init__(self, seed: Optional[int]=None) -> None:
        """Initializes the RandomAgent. If a seed is provided, the agent uses it to ensure reproducible random choices during testing."""
        raise NotImplementedError

    def choose_action(self, state_hash: int, possible_moves: List[int]) -> int:
        """Selects one action from the allowed moves.

        Args:
            state_hash: The current integer state hash (unused by this agent).
            possible_moves: A list of valid action indices available in the current state.

        Returns:
            int: A single action index chosen uniformly at random from `possible_moves`. If `possible_moves` is empty, raises ValueError."""
        raise NotImplementedError
