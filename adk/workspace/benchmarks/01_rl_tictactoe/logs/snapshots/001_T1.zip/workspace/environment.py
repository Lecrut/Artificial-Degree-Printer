"""Provides a custom Tic-Tac-Toe Gymnasium environment where observations are integer state hashes compatible with direct Q-table indexing."""
import gymnasium as gym
from gymnasium import spaces
import numpy as np
from typing import Tuple, Dict, Any, Optional
BOARD_SIZE: int = 3
NUM_ACTIONS: int = 9
PLAYER_X: int = 1
PLAYER_O: int = -1
DRAW_REWARD: float = 0.5
WIN_REWARD: float = 1.0
LOSS_REWARD: float = -1.0

class TicTacToeEnv(gym.Env):
    """A Tic-Tac-Toe environment implementing the Gymnasium API.

    The environment manages a 3x3 board. The agent plays as Player X (value 1). Actions are indices 0-8 corresponding to empty cells. The observation is an integer hash of the board state, suitable for direct Q-table indexing."""
    observation_space: spaces.Discrete
    action_space: spaces.Discrete

    def __init__(self) -> None:
        """Initializes the environment. Sets up observation and action spaces."""
        raise NotImplementedError

    def reset(self, seed: Optional[int]=None) -> Tuple[int, Dict[str, Any]]:
        """Resets the environment to the initial empty board state.

        Returns:
            tuple: A tuple containing the initial observation (integer hash of empty board) and an info dict (empty)."""
        raise NotImplementedError

    def step(self, action: int) -> Tuple[int, float, bool, bool, Dict[str, Any]]:
        """Processes one time step.

        Args:
            action: An integer 0-8 representing the chosen cell.

        Returns:
            tuple: (observation, reward, terminated, truncated, info)
                - observation: The integer hash of the new board state.
                - reward: Reward for the agent (+1 if win, -1 if loss, +0.5 if draw, 0 otherwise).
                - terminated: True if the game ended by win/loss/draw.
                - truncated: Always False (no time limit within an episode).
                - info: Dict containing 'valid_move' and 'winner' information."""
        raise NotImplementedError

    def get_state_hash(self, state: np.ndarray) -> int:
        """Computes the integer hash for a given numpy board array.

        Args:
            state: A 3x3 numpy array representing the board.

        Returns:
            int: A unique integer identifier for the state."""
        raise NotImplementedError

    def _get_available_moves(self) -> list:
        """Returns a list of available action indices (empty cells).

        Returns:
            list: List of integers 0-8 corresponding to empty cells."""
        raise NotImplementedError

    def _check_winner(self) -> Optional[int]:
        """Checks if there is a winner or if the board is full.

        Returns:
            Optional[int]: PLAYER_X (1) if X wins, PLAYER_O (-1) if O wins, 0 for draw, None if game continues."""
        raise NotImplementedError
