"""Implements Tic-Tac-Toe game logic as a Gymnasium-compatible environment and provides utilities for episode simulation."""
import gymnasium as gym
import numpy as np
from typing import Any, Dict, List, Optional, Tuple

class TicTacToeEnv(gym.Env):
    """A Gymnasium environment for the Tic-Tac-Toe game, using a flat action space and 3x3 grid observation."""
    action_space: gym.spaces.Discrete
    observation_space: gym.spaces.Box

    def __init__(self) -> None:
        """Initializes the Tic-Tac-Toe environment. Sets up action and observation spaces."""
        raise NotImplementedError

    def reset(self, seed: Optional[int]=None) -> tuple[np.ndarray, dict]:
        """Resets the environment to the initial state (empty board). Returns the initial observation (3x3 numpy array of 0s where 0=empty, 1=X, -1=O) and an info dictionary."""
        raise NotImplementedError

    def step(self, action: int) -> tuple[np.ndarray, float, bool, bool, dict]:
        """Takes a step in the environment. Returns obs (3x3 numpy array representing current board), reward (float: 1 for win, -1 for loss, 0 otherwise), done (bool indicating terminal state), trunc (bool always False), info (dict with game state details including whose turn it is and who won)."""
        raise NotImplementedError

    def get_valid_actions(self, obs: np.ndarray) -> list[int]:
        """Returns a list of valid action indices (0-8 corresponding to board cells) for the given observation. Returns an empty list if the game is already finished or invalid state is passed."""
        raise NotImplementedError

def run_episode(env: gym.Env, agent_p1: Any, agent_p2: Any, player_turn: str='X') -> dict:
    """Simulates a complete episode of Tic-Tac-Toe. Returns a dictionary with keys 'info' (the final step info dict containing the terminal state details) and 'turns' (list of tuples: (state_before_action, action_taken))."""
    raise NotImplementedError

def parse_episode_result(info: dict, p1_id: str, p2_id: str) -> dict:
    """Parses the final step info to determine game outcome. Returns a dictionary with keys 'winner' (str representing the winning player id or None for draw), 'result' ('win', 'loss', or 'draw' from perspective of p1), and 'rewards' (dict mapping player ids to their final accumulated rewards, typically 1 for win, -1 for loss, 0 for draw)."""
    raise NotImplementedError
