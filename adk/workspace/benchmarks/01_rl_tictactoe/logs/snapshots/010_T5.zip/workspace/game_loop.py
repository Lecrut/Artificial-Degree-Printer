"""Provides the logic to run a single episode of Tic-Tac-Toe between two agents and returns the outcome."""
from typing import Callable
import numpy as np
from tictactoe_env import TicTacToeEnv, get_valid_moves

def play_game(agent_a: Callable[[np.ndarray], int], agent_b: Callable[[np.ndarray, np.random.Generator], int], is_agent_a_turn: bool, rng: np.random.Generator) -> dict:
    """Runs a complete game of Tic-Tac-Toe between two agents or one random player.

    Executes turns alternately until termination (win or draw). The agent who moves first is determined by `is_agent_a_turn`. Agents receive the current board state; Agent B also receives an RNG for stochastic selection. Returns: {'winner': str, 'moves': list, 'final_board': np.ndarray, 'total_turns': int, 'rewards_A': float, 'rewards_B': float}.
    """
    from typing import Any
    env = TicTacToeEnv()
    obs = env.reset()
    history: list[Any] = []
    rewards_a_sum: float = 0.0
    rewards_b_sum: float = 0.0
    total_turns: int = 0
    current_player_id: int = env.PLAYER_X if is_agent_a_turn else env.PLAYER_O
    while True:
        valid_moves = get_valid_moves(env)
        if not valid_moves:
            obs = env.board.copy()
            final_draw: bool = True
            break
        total_turns += 1
        action_index = -1
        if current_player_id == env.PLAYER_X:
            state = obs
            next_action = agent_a(state)
        else:
            state = obs
            next_action = agent_b(state, rng)
        if next_action in valid_moves:
            obs = env.step(next_action)
            reward: float = 0.0
            terminated: bool = obs[2]
            info: dict = obs[3]
            if current_player_id == env.PLAYER_X:
                rewards_a_sum += reward
            else:
                rewards_b_sum += reward
            total_turns += 1
            win: bool = False
            loss: bool = False
            draw_check: bool = False
            if env.draw:
                winner_str: str = 'draw'
                final_draw = True
                win = False
                loss = False
                draw_check = True
            elif env.winner == env.PLAYER_X:
                winner_str = 'A'
                reward = 1.0
                final_draw = False
                win = True
                loss = False
            elif env.winner == env.PLAYER_O:
                winner_str = 'B'
                reward = -1.0
                final_draw = False
                win = False
                loss = True
            else:
                winner_str = 'unknown'
                final_draw = False
                win = False
                loss = False
            history.append(current_player_id)
        else:
            obs = env.step(next_action)
            reward: float = 0.0
            terminated: bool = obs[2]
            info: dict = obs[3]
            total_turns += 1
            invalid_info: bool = True if info.get('valid_move', False) else False
            history.append(current_player_id)
        current_player_id = env.current_player
        obs = env.board.copy()
    player_moves: list[dict] = []
    for idx, player_id in enumerate(history):
        if player_id == env.PLAYER_X:
            player_id_str = 'A'
        else:
            player_id_str = 'B'
        pass
    env2 = TicTacToeEnv()
    obs2 = env2.reset()
    history_moves: list[tuple[int, int]] = []
    current_player_id = env2.PLAYER_X if is_agent_a_turn else env2.PLAYER_O
    while True:
        valid_moves = get_valid_moves(env2)
        if not valid_moves:
            break
        total_turns += 1
        state = obs2.copy()
        next_action = -1
        if current_player_id == env2.PLAYER_X:
            next_action = agent_a(state)
        else:
            next_action = agent_b(state, rng)
        history_moves.append((current_player_id, next_action))
        obs2_new, reward, terminated, info = env2.step(next_action)
        current_player_id = env2.current_player
        if current_player_id == env2.PLAYER_X:
            rewards_a_sum += reward
        else:
            rewards_b_sum += reward
        if env2.draw:
            winner_str = 'draw'
        elif env2.winner == env2.PLAYER_X:
            winner_str = 'A'
        elif env2.winner == env2.PLAYER_O:
            winner_str = 'B'
        obs2 = obs2_new
        if terminated:
            break
    final_board: np.ndarray = obs2.copy()
    player_moves_list: list[dict] = []
    for pid, act in history_moves:
        player_str = 'A' if pid == env.PLAYER_X else 'B'
        player_moves_list.append({'player': player_str, 'action': act})
    return {'winner': winner_str, 'moves': player_moves_list, 'final_board': final_board, 'total_turns': total_turns, 'rewards_A': rewards_a_sum, 'rewards_B': rewards_b_sum}
