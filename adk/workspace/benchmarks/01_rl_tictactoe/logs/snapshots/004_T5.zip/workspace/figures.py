"""Reads experiment results and training history to generate static plots."""
import matplotlib
import matplotlib.pyplot as plt
import os
from typing import List
FIGURES_DIR: str = 'figures'

def plot_results() -> None:
    """Read `results.csv` and `training_history.csv`, generate and save plots.
    
    Reads two files from the workspace root:
    1. `results.csv`: Contains final aggregated metrics (`method`, `metric`, `value`).
       Used for the payoff comparison bar chart (win/draw/loss rates).
    2. `training_history.csv`: Contains training progress (`episode`, `reward`).
       Used for the learning curve visualization.

    Generates two figures and saves them into the `figures/` directory:
    1. `q_learning_curve.png`: Line plot of average reward over episodes.
    2. `payoff_comparison.png`: Bar chart comparing win/draw/loss rates between methods.
    
    Ensures the `figures/` directory exists before saving.
    """
    raise NotImplementedError
