"""Defines all experiment hyperparameters and run settings as module-level constants."""
N_EPISODES: int = 1000
N_TEST_GAMES: int = 500
N_RUNS: int = 5
SEED_BASE: int = 42
