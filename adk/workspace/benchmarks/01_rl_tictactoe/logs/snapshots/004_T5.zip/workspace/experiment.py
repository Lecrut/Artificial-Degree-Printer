"""Executes the training and evaluation loops for Q-Learning on Tic-Tac-Toe.

This module orchestrates the interaction between `TicTacToeEnv`, `QLearningAgent`,
and `RandomBaselineAgent` to generate metrics required by the thesis.
"""
import numpy as np
import pandas as pd
from typing import List, Dict, Any
from environment import TicTacToeEnv, RandomAgent
from agent import QLearningAgent, encode_state
from config import N_EPISODES, N_TEST_GAMES, N_RUNS, SEED_BASE

def _play_single_game(env: TicTacToeEnv, agents: tuple) -> Dict[str, float]:
    """Execute one game between two agents and return its result metrics.

    Plays a single full episode of Tic-Tac-Toe. The environment is reset at the start.
    Agents take turns choosing actions until termination (win/loss/draw).

    Args:
        env: A fresh or reset Gymnasium-compatible TicTacToeEnv instance.
        agents: A tuple of two objects implementing `select_action(state) -> int`.
                The first agent plays as 'X' (state 1), the second as 'O' (state 2).

    Returns:
        metrics: A dictionary containing results for the first agent (agent1):
            - 'reward' (float): Terminal reward received by agent1 (+1.0 win, 0.0 draw, -1.0 loss).
            - 'done' (bool): Always True at return.
    """
    raise NotImplementedError

def _evaluate_agent(q_agent: QLearningAgent, env_template: TicTacToeEnv) -> Dict[str, float]:
    """Evaluate the trained Q-Agent against the Random Baseline for N_TEST_GAMES.

    Sets the Q-Agent's epsilon to 0 (greedy policy) before evaluation.
    Aggregates win, loss, and draw rates for the Q-Agent.

    Args:
        q_agent: The trained QLearningAgent instance. Its epsilon is temporarily set to 0.
        env_template: A TicTacToeEnv instance used to create new copies via `type(env)()` 
                      or simply reset if stateless enough (assuming fresh env per game for independence).

    Returns:
        metrics: A dictionary containing evaluation statistics for the Q-Agent:
            - 'win_rate' (float): Fraction of test games won by Q-Agent.
            - 'loss_rate' (float): Fraction of test games lost by Q-Agent.
            - 'draw_rate' (float): Fraction of test games drawn.
            - 'avg_reward' (float): Mean terminal reward for Q-Agent.
    """
    raise NotImplementedError

def _train_one_run(run_seed: int, env_template: TicTacToeEnv, agent_class: type, config_kwargs: dict) -> Dict[str, float]:
    """Run one repetition of training and evaluation.

    1. Set global seed for reproducibility within this run.
    2. Initialize Agent and Environment.
    3. Train for N_EPISODES against RandomAgent.
    4. Evaluate trained agent against RandomAgent.

    Args:
        run_seed: The random seed for this specific repetition.
        env_template: A TicTacToeEnv instance to clone or initialize with.
        agent_class: The class to instantiate, e.g., `QLearningAgent`.
        config_kwargs: Arguments to pass to the agent constructor.

    Returns:
        metrics: A dictionary containing training and evaluation statistics:
            - 'train_avg_reward' (float): Mean terminal reward during the last 10% of training episodes.
            - 'win_rate' (float): Win rate in evaluation phase.
            - 'loss_rate' (float): Loss rate in evaluation phase.
            - 'draw_rate' (float): Draw rate in evaluation phase.
    """
    raise NotImplementedError

def run_experiment() -> pd.DataFrame:
    """Run the full training and evaluation experiment and return aggregated results.

    This function acts as the entrypoint for the experiment. It performs ``N_RUNS``
    independent repetitions to account for stochasticity. In each repetition:
    1. Initializes `TicTacToeEnv`, `QLearningAgent` (with epsilon-greedy), and uses `RandomAgent` as opponent.
    2. Trains the Q-Learning agent for ``N_EPISODES`` episodes against the random baseline.
    3. Evaluates the trained `QLearningAgent` against `RandomBaselineAgent` for ``N_TEST_GAMES``
       games using a greedy policy (epsilon=0).

    Aggregates metrics across all runs into a tidy DataFrame with columns:
    'method', 'metric', 'value', 'std_dev', 'n_runs'.

    Metrics included:
        - 'train_avg_reward' (training): Mean episode return during the last 10% of training.
        - 'win_rate' (eval): Win rate of Q-Learning vs Random in test games.
        - 'loss_rate' (eval): Loss rate of Q-Learning vs Random in test games.
        - 'draw_rate' (eval): Draw rate of Q-Learning vs Random in test games.

    Returns:
        results_df: A pandas DataFrame with shape ``(num_metrics, 5)`` 
                    containing the aggregated mean and std_dev over ``N_RUNS`` repetitions for each metric.
                    The 'method' column will be 'Q-Learning'.
    """
    raise NotImplementedError
