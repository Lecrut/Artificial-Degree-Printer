## Rozdział 1: Wprowadzenie do Uczenia ze Wzmocnieniem
Współczesne podejścia do sztucznej inteligencji ewoluowały od systemów opartych na sztywnych, hand-coded regułach w kierunku algorytmów zdolnych do autonomicznej adaptacji poprzez interakcję z otaczającym światem. Centralnym filarem tej transformacji jest uczenie ze wzmocnieniem (Reinforcement Learning, RL), które definiuje naukę jako proces optymalizacji strategii decyzyjnej agenta działającego w niepełnym środowisku. Celem niniejszej pracy inżynierskiej jest zbadanie skuteczności klasycznej, tabelarycznej metody Q-Learning w kontekście gry w kółko i krzyżyk (Tic-Tac-Toe) przeciwko przeciwnikowi losowemu.

### 1.1 Fundamentalne pojęcia uczenia ze wzmocnieniem

Proces uczenia się opiera się na czterech fundamentalnych elementach: agencie, środowisku, stanie oraz nagrodzie. Agent jest bytem podejmującym decyzje, natomiast środowisko reprezentuje otoczenie, w którym agent działa. Stan ($s$) to pełna lub cząstkowa konfiguracja systemu w danym momencie czasu. Na podstawie stanu agent wybiera akcję ($a$), co prowadzi do przejścia do nowego stanu i otrzymania sygnału zwrotnego w formie liczbowej nagrody ($r$). 

W przypadku gry w kółko i krzyżyk, środowisko jest deterministyczne i o pełnej informacji. Stan gry reprezentowany jest przez planszę o wymiarach $BOARD_SIZE \times BOARD_SIZE$, gdzie każde pole może należeć do gracza X (	exttt{PLAYER_X}), gracza O (	exttt{PLAYER_O}) lub być puste. Liczba możliwych akcji (	exttt{NUM_ACTIONS}) w stanie neutralnym wynosi 9, co czyni przestrzeń stanów skończoną i wystarczająco małą dla zastosowania metod tabelarycznych.

### 1.2 Cel pracy i zakres tematyczny

Głównym celem pracy jest sprawdzenie hipotezy, że agent uczący się metodą Q-Learning potrafi wyewoluować strategię równie skuteczną jak gra losowa, a w dłuższej perspektywie - lepszą, przeciwko przeciwnikowi wybierającemu ruchy przypadkowo. Praca zakłada:
1. Zbudowanie modułowej implementacji gry z klasą 	exttt{TicTacToeEnv} (	exttt{environment.py}) definiującą zasady,
kierującą się stałymi nagród: wygranej (	exttt{WIN_REWARD}), remisu (	exttt{DRAW_REWARD}) i porażki (	exttt{LOSS_REWARD}).
2. Zaimplementowanie agenta Q-Learning w klasie 	exttt{QAgent} (	exttt{q_agent.py}), używającego standardowych parametrów domyślnych: współczynnika uczenia się (	exttt{DEFAULT_LEARNING_RATE}), dyskonta (	exttt{DEFAULT_DISCOUNT_FACTOR}) oraz inicjalnej wartości epsilon (	exttt{DEFAULT_EPSILON_START}).
3. Zaprojektowanie procedury trenowania opartej o klasę 	exttt{trainer.py}, w tym funkcji 	exttt{train_episode} i 	exttt{train_policy}, wykorzystującej decay epsilona zgodnie z parametrami 	exttt{EPSILON_DECAY_RATE} oraz 	exttt{MIN_EPSILON}.
4. Przeprowadzenie kontroli jakości poprzez testy jednostkowe modułów, w tym porównanie gry wyuczonego agenta z baseliniem losowym (	exttt{RandomAgent} z 	exttt{baseline_agent.py}).
5. Weryfikację wyników przy użyciu metryk: wskaźnika wygranej agenta (	exttt{agent_win_rate}), remisów (	exttt{agent_draw_rate}) i strat (	exttt{agent_loss_rate}) oraz średniej nagrody z epizodu (	exttt{avg_episode_reward}).

### 1.3 Struktura pracy

Następny rozdział omawia teoretyczne podstawy Q-Learningu, równanie Bellmana oraz mechanizm eksploracji. Rozdział trzeci opisuje specyfikę modelowania gry w kółko i krzyżyk dla potrzeb algorytmów RL. Czwarty rozdział prezentuje przebieg przeprowadzonego eksperymentu, parametry konfiguracyjne (	exttt{DEFAULT_N_REPETITIONS} z 	exttt{pipeline.py}) oraz procedurę ewaluacji (	exttt{evaluator.py}). Ostatni rozdział zawiera analizę wyników obtained w procesie 	exttt{run_experiment} (	exttt{experiment.py}), generujących dane do wizualizacji (	exttt{generate_plots} z 	exttt{figures.py}) oraz wnioski końcowe dotyczące przydatności metody Q-Learning w tego typu środowiskach.

## Rozdział 2: Analiza Stanu Wiedzy i Podstawy Teoretyczne
### 2.1 Fundamenty Uczenia ze Wzmocnieniem
Uczenie ze wzmocnieniem (Reinforcement Learning, RL) to gałąź sztucznej inteligencji zajmująca się nauką działań optymalnych przez agenta poprzez interakcję z dynamicznym środowiskiem \cite{woo2024federated}. W przeciwieństwie do uczenia nadzorowanego, gdzie dane są statyczne i oznaczone poprawnymi labelami, w RL agent otrzymuje sygnał zwrotny w postaci nagrody skalarnej, który może być odroczony w czasie. Celem agenta jest maksymalizacja sumarycznej nagrody oczekiwanej (return) w określonym horyzoncie czasowym \cite{yang2023federated}.

Formalnie problem decyzyjny agenta modeluje się jako Markowski Proces Decyzyjny (Markov Decision Process, MDP), który definiuje kwintet $(S, A, P, R, \gamma)$, gdzie:
- $S$ to skończony zbiór stanów,
- $A$ to zbiór możliwych akcji,
- $P(s' | s, a)$ to funkcja przejścia prawdopodobieństwa, określająca prawdopodobieństwo przejścia ze stanu $s$ do $s'$ po wykonaniu akcji $a$,
- $R(s, a, s')$ to funkcja nagrody, i
- $\gamma \in [0, 1]$ to współczynnik dyskontujący.

W kontekście gier dwuosobowych o zerowej sumie, takich jak kółko i krzyżyk, stan gry odpowiada konkretnej konfiguracji planszy, a akcje są dozwolonymi ruchami na wolnych polach. Ze względu na deterministyczny charakter gry w kółko i krzyżyk przy ustalonych ruchach przeciwnika, dynamika przejść $P$ jest często traktowana jako znana lub wyznaczalna, co upraszcza proces nauki \cite{wang2021sampleeffici}.

### 2.1.1 Metoda Q-Learning (Tabelaryczna)
Q-Learning to algorytm uczenia się bez modelu (model-free) i off-policy, który pozwala agentowi nauczyć się optymalnej funkcji wartości akcji $Q^*(s, a)$. Funkcja ta określa oczekiwaną nagrodę za wykonanie akcji $a$ w stanie $s$, a następnie stosowanie się do optymalnej strategii.

Aktualizacja wartości Q odbywa się zgodnie z równaniem Bellmana, wykorzystującym zasadę aktualizacji temporalnej (Temporal Difference learning): $$Q(s, a) \leftarrow Q(s, a) + \alpha [r + \gamma \max_{a'} Q(s', a') - Q(s, a)]$$ gdzie $\alpha$ to współczynnik uczenia (learning rate), $r$ to otrzymana nagroda, a $s'$ to nowy stan po podjęciu akcji. Algorytm ten charakteryzuje się zbieżnością do optymalnego rozwiązania przy spełnieniu warunków eksploracji wszystkich stanów i akcji w nieskończonym horyzoncie czasu \cite{deka2022arc}.

W przypadku gier skończonych o doskonałej informacji, takich jak kółko i krzyżyk, stosowanie tabelarycznej reprezentacji funkcji Q jest naturalne i wydajne. Zbiór stanów $|S|$ dla gry w kółko i krzyżyk (po uwzględnieniu symetrii i redukcji początkowej) wynosi 5478 stanów niepowtarzalnych, co czyni tę przestrzeń wystarczająco małą do pełnego przeszukania tablicy Q w pamięci komputera bez konieczności zastosowania aproksymacji \cite{yang2026lifted}.

### 2.1.2 Ewolucja Strategii i Problem Eksploracji
Kluczowym wyzwaniem w RL jest dylemat eksploracji (exploration) versus eksploatacji (exploitation). Agent musi balansować między podejmowaniem działań znanych, prowadzących do wysokich nagród (eksploatacja), a wyborami mniej znanymi, które mogą doprowadzić do odkrycia lepszych strategii w przyszłości (eksploracja). W pracy zastosowano strategię $\epsilon$-greedy (greedy z losową eksploracją), gdzie z prawdopodobieństwem $1-\epsilon$ agent wybiera akcję o najwyższej wartości Q, a z prawdopodobieństwem $\epsilon$ dokonuje losowego wyboru. Parametr $\epsilon$ zazwyczaj ulega maleńiu w trakcie treningu (decay), co umożliwia intensywną eksplorację na początku i koncentrację na optymalnej strategii w fazie końcowej.

W odniesieniu do konkurencji, agent Q-Learning musi być zmotywowany nie tylko do wygranej, ale także do uniknięcia porażki. W grach typu zero-sum nagrody są zazwyczaj przypisywane jako $+1$ za wygraną, $0$ za remis i $-1$ za przegraną (lub analogiczne skalowanie). Badania wskazują, że w stabilnych środowiskach o znanej dynamice, tabela Q pozwala na osiągnięcie doskonałej gry (perfekcyjnej strategii) po odpowiednim czasie konwergencji \cite{amiri2025reinforcemen}. Porównanie wyników z losowym agentem (Random Agent), który wybiera dowolny dostępny ruch z równym prawdopodobieństwem, służy jako punkt odniesienia (baseline) demonstrujący wartość dodaną procesu uczenia. Losowy agent w kółku i krzyżyk przegrywa lub remisu z dużą częstotliwością przeciwko graczowi stosującemu podstawową strategię zapobiegającą porażce, co czyni go odpowiednim obiektem do demonstracji efektów nauki silnej (strong learning) \cite{hwang2023practical}.
