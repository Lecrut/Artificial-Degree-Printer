"""Provides evaluation utilities for Tic-Tac-Toe agents, including match simulation and metric computation."""
import numpy as np
from typing import Dict, Any, Optional, List, Tuple
from environment import TicTacToeEnv, WIN_REWARD, LOSS_REWARD, DRAW_REWARD
from q_agent import QAgent
from baseline_agent import RandomAgent

def evaluate_match(agent_a: Any, agent_b: Any, env_template: TicTacToeEnv, n_matches: int, epsilon: float) -> Dict[str, int]:
    """Simulates a series of matches between two agents and returns the result counts. The agents take turns as Player X (first mover) and Player O (second mover) across the specified number of matches to balance advantage. For `QAgent` instances, this function passes `epsilon` during action selection to control exploration levels during evaluation. Returns a dictionary with keys 'wins_agent_a' (int), 'wins_agent_b' (int), and 'draws' (int). The sum of these values will be equal to `n_matches` unless an exception occurs. If an agent raises an exception during play, that match is not counted in totals but does not stop execution. Handles edge cases such as n_matches=0 (returns all zeros)."""
    if n_matches == 0:
        return {'wins_agent_a': 0, 'wins_agent_b': 0, 'draws': 0}
    wins_a = 0
    wins_b = 0
    draws = 0
    for i in range(n_matches):
        env = type(env_template)()
        obs, _ = env.reset(seed=i)
        done = False
        winner = None
        while not done:
            pass
        env = type(env_template)()
        obs, _ = env.reset(seed=i)
        done = False
        truncated = False
        turn_count = 0
        while not (done or truncated):
            try:
                possible_moves = env._get_available_moves()
            except AttributeError:
                raise RuntimeError('Environment does not expose available moves for the evaluator.')
            if not possible_moves:
                break
            current_player = 1 if turn_count % 2 == 0 else -1
            if current_player == 1:
                if isinstance(agent_a, QAgent) or (hasattr(agent_a, 'choose_action') and hasattr(agent_a, '_rng')):
                    if current_player == 1:
                        action = agent_a.choose_action(env.get_state_hash(env.state) if hasattr(env, 'state') else 0, possible_moves, epsilon)
                    else:
                        action = agent_b.choose_action(env.get_state_hash(env.state) if hasattr(env, 'state') else 0, possible_moves, epsilon)
                elif current_player == 1:
                    action = agent_a.choose_action(env.get_state_hash(env.state) if hasattr(env, 'state') else 0, possible_moves, epsilon)
                else:
                    action = agent_b.choose_action(env.get_state_hash(env.state) if hasattr(env, 'state') else 0, possible_moves, epsilon)
            pass
    return {}

def compute_metrics(win_rate: float, win_count: int, draw_count: int, loss_count: int, n_matches: int, baseline_win_rate: float=0.0, baseline_draw_rate: float=0.0) -> Dict[str, float]:
    """Computes performance metrics from raw match counts and rates."""
    if n_matches == 0:
        return {'agent_win_rate': 0.0, 'agent_draw_rate': 0.0, 'agent_loss_rate': 0.0, 'vs_baseline_advantage': -baseline_win_rate, 'vs_baseline_draw_advantage': -baseline_draw_rate}
    loss_rate = loss_count / n_matches
    return {'agent_win_rate': win_rate, 'agent_draw_rate': draw_count / n_matches, 'agent_loss_rate': loss_rate, 'vs_baseline_advantage': win_rate - baseline_win_rate, 'vs_baseline_draw_advantage': draw_count / n_matches - baseline_draw_rate}
