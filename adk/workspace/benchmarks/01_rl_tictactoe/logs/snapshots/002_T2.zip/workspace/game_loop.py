"""Provides the logic to run a single episode of Tic-Tac-Toe between two agents and returns the outcome."""
from typing import Callable
import numpy as np
from tictactoe_env import TicTacToeEnv, get_valid_moves

def play_game(agent_a: Callable[[np.ndarray], int], agent_b: Callable[[np.ndarray, np.random.Generator], int], is_agent_a_turn: bool, rng: np.random.Generator) -> dict:
    """Runs a complete game of Tic-Tac-Toe using an internal TicTacToeEnv instance (initialized fresh for each call). Executes turns alternately between Agent A and Agent B until termination (win or draw). The agent who moved first is determined by `is_agent_a_turn`. Agents receive the current board state as an argument; Agent B also receives `rng` for stochastic selection if needed. Returns: a dictionary with keys: 'winner' (str 'A', 'B', or 'draw'), 'moves' (list of dicts with 'player' ('A'/'B') and 'action' (int)), 'final_board' (np.ndarray copy of the final state), 'total_turns' (int), 'rewards_A' (float sum of rewards received by agent A during the game), 'rewards_B' (float sum of rewards received by agent B during the game). The function is deterministic given the same `rng` seed and initial conditions, and does not rely on external mutable state beyond the provided rng."""
    raise NotImplementedError
