"""Implements the Tic-Tac-Toe game logic and a Gymnasium-compatible wrapper for interaction."""
from typing import Tuple, Dict, Any
import numpy as np
import gymnasium as gym

class TicTacToeEnv(gym.Env):
    """A standard 3x3 Tic-Tac-Toe environment compatible with the Gymnasium API.

    State encoding:
        The state is represented as a flat NumPy array of shape (9,), containing integers:
        - 0: Empty cell
        - 1: Player 'X' (first mover)
        - 2: Player 'O' (second mover)

    Action encoding:
        Actions are integers in the range [0, 8], corresponding to the index of the cell
        to occupy in the flattened 3x3 grid.
    """
    observation_space: gym.spaces.Box = ...
    action_space: gym.spaces.Discrete = ...

    def __init__(self) -> None:
        """Initialize the environment. Sets up spaces and internal state variables."""
        raise NotImplementedError

    def reset(self, seed: int | None=None, options: Dict[str, Any] | None=None) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Reset the environment to the initial state.

        Initializes the board to all zeros and sets the current player to 'X'.

        Args:
            seed: Optional random seed for reproducibility (ignored as the game 
                  start is deterministic). Used for Gymnasium compliance.
            options: Unused keyword arguments for Gymnasium compliance.

        Returns:
            observation: The initial board state (np.ndarray of shape (9,) with dtype int8).
            info: A dictionary containing metadata, including 'current_player' 
                  (int: 1 or 2).
        """
        raise NotImplementedError

    def step(self, action: int) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """Execute one time step in the environment.

        Places the current player's mark on the board at the given action index. 
        Checks for win, loss, or draw conditions. Switches the current player 
        if the game is not over.

        Args:
            action: The integer index of the cell to occupy (0-8).

        Returns:
            observation: The new board state after the action (np.ndarray of shape (9,)).
            reward: Reward for the current player (1.0 for win, 0.0 for draw, 
                    -1.0 for loss). If the game continues, reward is 0.0.
            terminated: True if the game ended by a win or loss.
            truncated: Always False for this finite horizon game without time limits.
            info: A dictionary containing:
                  'valid_action': bool indicating if the action was legal.
                  'winner': int (1 or 2) representing the winner, or None if no 
                            winner yet.
                  'current_player': int (1 or 2) of the player who will move next.
        """
        raise NotImplementedError

class RandomAgent:
    """A simple agent that selects a random valid action from the current state.

    This serves as the explicit baseline opponent for comparison in the experiment.
    """

    def select_action(self, state: np.ndarray) -> int:
        """Select a valid move randomly from the available empty cells.

        Args:
            state: The current board state (np.ndarray of shape (9,), values in {0, 1, 2}).

        Returns:
            action: An integer index [0-8] corresponding to an empty cell on the board.
                    Always returns a valid, legal move. If the board is full, returns -1 
                    (though this case should typically be handled by the environment stopping).
        """
        raise NotImplementedError
