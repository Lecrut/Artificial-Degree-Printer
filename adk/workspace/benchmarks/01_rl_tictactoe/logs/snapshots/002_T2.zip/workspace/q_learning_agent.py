"""Implements the Q-Learning agent with epsilon-greedy exploration and tabular policy updates for finite-state environments."""
import numpy as np
from typing import List, Dict, Tuple

class QLearningAgent:
    """A class representing an agent that learns a policy using tabular Q-Learning."""
    q_table: Dict[Tuple[int, ...], np.ndarray]
    learning_rate: float
    discount_factor: float
    epsilon: float
    initial_epsilon: float
    decay: float

    def __init__(self, learning_rate: float, discount_factor: float, initial_epsilon: float, decay: float) -> None:
        """Initializes the agent. Creates an empty Q-table dictionary mapping state tuples (representing board configurations) to numpy arrays of shape (BOARD_SIZE,) storing Q-values for each possible action. Stores hyperparameters. Sets epsilon to initial_epsilon. Returns no value."""
        raise NotImplementedError

    def act(self, state: np.ndarray, valid_moves: List[int]) -> int:
        """Returns an integer action index from valid_moves for the given state. Uses epsilon-greedy selection: with probability epsilon, chooses uniformly at random from valid_moves; otherwise selects the action in valid_moves that maximizes the Q-value for the current state (breaking ties randomly). If no Q-values exist for the state, defaults to random valid move. Returns an int in range [0, BOARD_SIZE)."""
        raise NotImplementedError

    def learn(self, state: np.ndarray, action: int, reward: float, next_state: np.ndarray, terminated: bool) -> None:
        """Updates the Q-value for the state-action pair using the Bellman equation. If the state is not in q_table, initializes its value array with zeros before updating. The update target is: reward + discount_factor * max(q_table[next_state]) if next_state exists and is non-terminal (terminated is False), else reward. This ensures correct credit assignment when the episode ends. Returns no value."""
        raise NotImplementedError

    def reset(self) -> None:
        """Resets the internal exploration rate epsilon to initial_epsilon for a new training phase. Does not reset or clear the Q-table, preserving learned policy. Returns no value."""
        raise NotImplementedError
