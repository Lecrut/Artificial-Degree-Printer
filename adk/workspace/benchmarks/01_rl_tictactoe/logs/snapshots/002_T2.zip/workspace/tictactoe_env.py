"""Defines the Tic-Tac-Toe game environment with state representation, move validation, and win/draw detection for reinforcement learning."""
import numpy as np
from typing import Optional
BOARD_SIZE: int = 9
EMPTY_CELL: int = 0
PLAYER_X: int = 1
PLAYER_O: int = -1

class TicTacToeEnv:
    """A class managing the Tic-Tac-Toe game state, including board initialization, move validation, and terminal condition tracking."""
    board: np.ndarray
    current_player: int
    history: list[int]
    terminal_state: bool
    winner: Optional[str]
    draw: bool

    def reset(self) -> dict:
        """Creates a new empty board (all zeros) and sets the first player to move to PLAYER_X (1). Returns a dictionary containing 'board' (np.ndarray of shape (BOARD_SIZE,), dtype int32), 'current_player' (int), 'history' (empty list), 'winner' (None), and 'draw' (False). The history list is cleared on each reset. All values are deterministic."""
        raise NotImplementedError

    def step(self, action: int) -> tuple[np.ndarray, float, bool, bool, dict]:
        """Executes a single turn by the current player. The action must be an integer index of a valid empty cell; if invalid (out of bounds or occupied), it does not update the board, sets terminated to False, returns a reward of 0, and includes an 'invalid_move' flag in info set to True. If valid, it updates the board, checks for win/draw conditions, switches the current player if the game continues, and sets terminated to True if a terminal state is reached. Returns: obs (np.ndarray copy of board), reward (float 1.0 if current player wins immediately, -1.0 if this move allows opponent to win? No, RL usually rewards terminal state of the actor, so +1 for self-win, -1 for self-loss, 0 otherwise), terminated (bool True if game ended), truncated (always False for finite horizon < BOARD_SIZE steps without termination logic specific to depth), info (dict with 'valid_move' bool and 'game_over' bool)."""
        raise NotImplementedError

def get_valid_moves(env: TicTacToeEnv) -> list[int]:
    """Returns a sorted list of integer indices representing all currently empty cells where the player can legally move. The function accesses the board state from the provided environment instance; if no moves are available (board is full), it returns an empty list."""
    raise NotImplementedError
