"""Implements a baseline opponent that selects uniformly at random from available moves using only the provided state and RNG."""
from typing import Any
import numpy as np

class RandomAgent:
    """A baseline agent that chooses moves uniformly at random, useful for evaluating the learning performance of a Q-Learning agent."""

    def __init__(self) -> None:
        """Initializes the RandomAgent with no internal state beyond the RNG provided during action selection. Returns None."""
        raise NotImplementedError

    def act(self, state: dict, rng: np.random.Generator) -> int:
        """Selects a valid move for the player corresponding to 'state' (either PLAYER_X or PLAYER_O). The action is chosen uniformly at random from the list of valid empty cells on the board. It uses the provided 'rng' object to generate the random number; if no valid moves exist, it returns -1. Returns an integer index of the cell to move into."""
        raise NotImplementedError
