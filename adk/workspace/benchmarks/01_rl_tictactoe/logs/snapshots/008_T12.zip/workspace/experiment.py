"""Orchestrates the training and evaluation of both a Q-Learning agent and a Random baseline agent in Tic-Tac-Toe across multiple seeds, writing aggregated results to results.csv."""
import config
import environment
import agent
import baseline
import numpy as np
import pandas as pd

def run_experiment() -> None:
    """Runs the full experiment pipeline for both Q-Learning and Random baseline agents.

    This function performs two distinct phases of experimentation, repeated for each seed in `config.SEEDS`:
    1. Q-Learning Training & Evaluation: Initializes a `QLearningAgent`, trains it against a fixed `RandomAgent` opponent for `config.NUM_EPISODES` episodes using epsilon-greedy policy with decay (`config.EPSILON_START`, `config.EPSILON_END`, `config.EPSILON_DECAY`). After training, evaluates the trained agent against the same `RandomAgent` for `config.TEST_EPISODES` episodes.
    2. Random Baseline Evaluation: Initializes a `RandomAgent` as Player 1 (P1) and another `RandomAgent` as Player 2 (P2). Plays `config.TEST_EPISODES` episodes to establish baseline metrics for win/loss/draw rates against itself.

    Metrics collected per method ('q_learning' and 'random_baseline') include: win_rate, loss_rate, draw_rate, and avg_reward. These are aggregated across all seeds and episodes, then written to a CSV file named `results.csv` in the current working directory with columns: `method`, `metric`, `value`. If an optional column `std_dev` is computed for metrics that support it (e.g., win_rate), it is included; otherwise, it is omitted.

    Conventions:
    - P1 is the agent being evaluated or trained. P2 is always a RandomAgent.
    - In the Q-Learning phase, P1 learns against P2's fixed random policy.
    - In the Baseline phase, both P1 and P2 play randomly to determine baseline performance.
    - `results.csv` contains one row per metric per method.

    Edge cases:
    - If `config.SEEDS` is empty, raises `ValueError`.
    - If `config.NUM_EPISODES` is less than 1, it defaults to 1 to prevent empty training loops.
    - If `config.TEST_EPISODES` is less than 1, it defaults to 1 to ensure evaluation occurs."""
    raise NotImplementedError
