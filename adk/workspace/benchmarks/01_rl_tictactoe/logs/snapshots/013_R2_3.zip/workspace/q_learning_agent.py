"""Implements the Q-Learning agent with epsilon-greedy exploration and tabular policy updates for finite-state environments."""
import random
import numpy as np
from typing import List, Dict, Tuple
BOARD_SIZE = 9

class QLearningAgent:
    """A class representing an agent that learns a policy using tabular Q-Learning."""
    q_table: Dict[Tuple[int, ...], np.ndarray]
    learning_rate: float
    discount_factor: float
    epsilon: float
    initial_epsilon: float
    decay: float

    def __init__(self, learning_rate: float, discount_factor: float, initial_epsilon: float, decay: float) -> None:
        """Initializes the agent with hyperparameters and creates an empty Q-table."""
        self.q_table = {}
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.initial_epsilon = initial_epsilon
        self.decay = decay
        self.epsilon = initial_epsilon

    def act(self, state: Tuple[int, ...], valid_moves: List[int]) -> int:
        """Returns an integer action index from valid_moves using epsilon-greedy policy.

    Args:
        state (Tuple[int, ...]): The game board state as a tuple of integers.
        valid_moves (List[int]): A list of valid move indices.

    Returns:
        int: The selected action index.
        """
        if isinstance(state, np.ndarray):
            state_tuple = tuple(state.tolist())
        elif isinstance(state, tuple):
            state_tuple = state
        else:
            raise ValueError(f'State must be a numpy array or tuple, got {type(state).__name__}')
        if random.random() < self.epsilon:
            return random.choice(valid_moves)
        initial_q = np.zeros(BOARD_SIZE)
        try:
            q_values = self.q_table[state_tuple]
        except KeyError:
            q_values = initial_q
        valid_q = [q_values[i] for i in valid_moves]
        max_action_idx = int(np.argmax(valid_q))
        return valid_moves[max_action_idx]

    def learn(self, state: np.ndarray, action: int, reward: float, next_state: np.ndarray, terminated: bool) -> None:
        """Updates the Q-value for the state-action pair using the Bellman equation."""
        state_tuple = tuple(state.tolist())
        if state_tuple not in self.q_table:
            self.q_table[state_tuple] = np.zeros(BOARD_SIZE)
        q_current = self.q_table[state_tuple][action]
        if terminated:
            target = reward
        else:
            next_state_tuple = tuple(next_state.tolist())
            max_q_next = 0.0
            if next_state_tuple in self.q_table:
                max_q_next = float(np.max(self.q_table[next_state_tuple]))
            target = reward + self.discount_factor * max_q_next
        new_q = q_current + self.learning_rate * (target - q_current)
        self.q_table[state_tuple][action] = new_q

    def reset(self) -> None:
        """Resets the internal exploration rate epsilon to initial_epsilon."""
        self.epsilon = self.initial_epsilon
