"""Provides the logic to run a single episode of Tic-Tac-Toe between two agents and returns the outcome."""
from typing import Callable, Any
import numpy as np
from tictactoe_env import TicTacToeEnv, PLAYER_X, PLAYER_O, get_valid_moves

def play_game(agent_a: Callable[[np.ndarray], int], agent_b: Callable[[np.ndarray, np.random.Generator], int], is_agent_a_turn: bool, rng: np.random.Generator) -> dict:
    """Runs a complete game of Tic-Tac-Toe between two agents or one random player.

    Executes turns alternately until termination (win or draw). The agent who moves first is determined by `is_agent_a_turn`. Agents receive the current board state; Agent B also receives an RNG for stochastic selection. Returns: {'winner': str, 'moves': list, 'final_board': np.ndarray, 'total_turns': int, 'rewards_A': float, 'rewards_B': float}.
    """
    from typing import Callable
    import numpy as np
    from tictactoe_env import TicTacToeEnv, PLAYER_X, PLAYER_O, get_valid_moves, BOARD_SIZE
    env = TicTacToeEnv()
    obs = env.reset()
    history: list[dict] = []
    rewards_a_sum: float = 0.0
    rewards_b_sum: float = 0.0
    total_turns: int = 0
    current_player_id: int = PLAYER_X if is_agent_a_turn else PLAYER_O
    while True:
        valid_moves = get_valid_moves(env)
        state: np.ndarray = obs.copy()
        next_action: int = -1
        if current_player_id == PLAYER_X:
            next_action = agent_a(state)
        else:
            next_action = agent_b(state, rng)
        obs_new, reward, terminated, truncated, info = env.step(next_action)
        if current_player_id == PLAYER_X:
            rewards_a_sum += reward
        else:
            rewards_b_sum += reward
        winner_str: str = 'draw'
        if terminated:
            if env.winner is not None:
                winner_str = str(env.winner)
        player_label: str = 'A' if current_player_id == PLAYER_X else 'B'
        history.append({'player': player_label, 'action': next_action})
        total_turns += 1
        obs = obs_new
        if terminated:
            break
        if obs_new is not None and np.all(obs_new != TicTacToeEnv().reset()['board']):
            pass
        if total_turns >= BOARD_SIZE:
            break
    return {'winner': winner_str, 'moves': history, 'final_board': obs.copy(), 'total_turns': total_turns, 'rewards_A': rewards_a_sum, 'rewards_B': rewards_b_sum}
