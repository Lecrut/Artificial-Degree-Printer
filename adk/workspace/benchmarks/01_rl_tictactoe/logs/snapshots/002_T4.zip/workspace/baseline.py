"""Provides a random baseline agent for Tic-Tac-Toe that selects uniformly from valid moves."""
from typing import List, Optional
import numpy as np

class RandomAgent:
    """A baseline agent that chooses uniformly at random from the set of valid actions."""

    def __init__(self) -> None:
        """Initializes the random baseline agent. No state is required as action selection depends only on the input list of valid actions."""
        raise NotImplementedError

    def choose_action(self, valid_actions: List[int], rng: Optional[np.random.Generator]=None) -> int:
        """Selects an action uniformly at random from `valid_actions`.

        - Returns: An integer representing the chosen action index, drawn from `valid_actions`.
        - Edge cases:
          - If `valid_actions` is empty, raises `ValueError` (should not happen if environment logic is correct).
          - If `valid_actions` contains a single element, returns that element deterministically.
          - If `rng` is None, uses the global numpy random generator."""
        raise NotImplementedError
