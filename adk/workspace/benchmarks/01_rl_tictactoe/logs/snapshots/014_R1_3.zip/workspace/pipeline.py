"""Orchestrates training and evaluation workflows to reduce coupling in the entrypoint."""
from typing import Dict, Any, Optional
import numpy as np
from q_agent import QAgent
from baseline_agent import RandomAgent
from trainer import train_policy
from evaluator import evaluate_match, compute_metrics
DEFAULT_N_REPETITIONS: int = 10

def run_training_pipeline(env_params: Dict[str, Any], agent_params: Dict[str, Any]) -> tuple:
    """Orchestrates the training of a Q-Learning agent against a random baseline.

    Initializes a new `QAgent` using `agent_params` (specifically `n_states`, `n_actions`, and learning hyperparameters) and an empty logger. It then calls `train_policy` to run the simulation with `env_params`. Returns a tuple containing:
    1. The aggregated training statistics dictionary from `train_policy` (keys: 'final_epsilon', 'total_episodes', 'avg_rewards_100', 'convergence_step').
    2. The trained `QAgent` instance that was used, allowing the caller to access its Q-table for evaluation.

    Args:
        env_params: Dictionary of parameters for `TicTacToeEnv` initialization (currently unused or empty).
        agent_params: Dictionary containing hyperparameters for the agent. Keys include 'n_states', 'n_actions', 'lr', 'gamma', 'epsilon_start', 'epsilon_decay', 'epsilon_end'.

    Returns:
        tuple: A tuple of (training_stats: Dict[str, Any], trained_agent: QAgent)."""
    raise NotImplementedError

def run_evaluation_pipeline(q_agent: QAgent, n_repetitions: int, seed: Optional[int]=None) -> Dict[str, Any]:
    """Orchestrates the evaluation of a trained Q-Learning agent against baselines over multiple repetitions.

    Runs `evaluate_match` for 'agent vs baseline' and 'baseline vs baseline' (`n_repetitions` times each) to quantify statistical variance. Aggregates results across repetitions using `compute_metrics`. Returns a dictionary containing:
    - 'agent_vs_baseline': Metrics for the agent against the random baseline. Includes 'agent_win_rate', 'agent_draw_rate', 'agent_loss_rate' (mean rates), and 'std_dev' (standard deviation of win rates across repetitions).
    - 'baseline_vs_baseline': Metrics for the random baseline against itself. Includes 'baseline_win_rate', 'baseline_draw_rate', 'vs_baseline_advantage' (mean advantage), and 'n_runs' (number of repetitions used, equal to `n_repetitions`).

    Args:
        q_agent: The trained `QAgent` instance to evaluate.
        n_repetitions: Number of independent evaluation runs to perform for statistical significance. Must be > 0.
        seed: Optional base seed for reproducibility. Passed to `RandomAgent` instances as `seed + i` for the i-th repetition to ensure variance is calculated correctly and results are reproducible.

    Returns:
        dict: A dictionary containing aggregated mean metrics and standard deviations/n_runs for both evaluations."""
    raise NotImplementedError
