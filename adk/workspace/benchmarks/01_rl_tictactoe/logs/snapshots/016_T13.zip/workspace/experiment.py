"""Entrypoint module that orchestrates the full training and evaluation experiment pipeline for a Q-Learning agent playing Tic-Tac-Toe."""
import csv
import os
from typing import Dict, Any
from pipeline import run_training_pipeline, run_evaluation_pipeline
RESULTS_FILENAME: str = 'results.csv'
FIGURES_DIRNAME: str = 'figures'

def run_experiment() -> None:
    """Runs the complete experiment: training, evaluation, and saving results to CSV. Executes `run_training_pipeline` with default hyperparameters, then `run_evaluation_pipeline`. Aggregates the resulting metrics (agent_win_rate, agent_draw_rate, agent_loss_rate, baseline_win_rate, baseline_draw_rate) and avg_episode_reward into a list of rows. Writes these rows to `results.csv` in the current working directory with headers: method, metric, value. Creates the `figures/` directory if it does not exist (to prepare for future plot generation)."""
    raise NotImplementedError
