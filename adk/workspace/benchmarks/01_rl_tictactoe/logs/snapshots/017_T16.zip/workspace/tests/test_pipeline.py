import pytest
from unittest.mock import patch, MagicMock
import numpy as np
import pipeline
from q_agent import QAgent
from baseline_agent import RandomAgent
from trainer import train_policy


class TestRunTrainingPipeline:
    """Test run_training_pipeline by mocking train_policy."""

    def test_returns_tuple_of_stats_and_agent(self):
        """Verify the return type and structure of run_training_pipeline.

        The function should return a tuple containing (stats_dict, trained_agent).
        We mock train_policy to return specific dummy values and verify
        that run_training_pipeline returns them unchanged.
        """
        # Arrange
        env_params = {}
        agent_params = {
            'n_states': 100,
            'n_actions': 9,
            'lr': 0.1,
            'gamma': 0.99,
            'epsilon_start': 1.0,
            'epsilon_decay': 0.999,
            'epsilon_end': 0.01
        }
        mock_stats = {
            'final_epsilon': 0.05,
            'total_episodes': 10000,
            'avg_rewards_100': -0.1,
            'convergence_step': 5000
        }
        # Use MagicMock instead of real QAgent to avoid index errors during initialization if q_table logic is triggered
        # The test is about the pipeline's orchestration, not QAgent's internal state correctness here.
        mock_agent = MagicMock(spec=QAgent)

        # Act
        with patch('trainer.train_policy', return_value=(mock_stats, mock_agent)) as mock_train:
            with patch('q_agent.QAgent', return_value=mock_agent):
                result = pipeline.run_training_pipeline(env_params, agent_params)

        # Assert
        assert isinstance(result, tuple), "Result must be a tuple"
        assert len(result) == 2, "Result must have length 2 (stats, agent)"

        returned_stats, returned_agent = result

        # Check that train_policy was called with correct arguments
        mock_train.assert_called_once()

        # Check returned values match mock
        assert returned_stats == mock_stats, "Returned stats should match train_policy output"
        assert returned_agent is mock_agent, "Returned agent should be the one created by QAgent and passed to train_policy"

    def test_calls_qagent_with_correct_params(self):
        """Verify that run_training_pipeline initializes QAgent with correct n_states and n_actions."""
        env_params = {}
        agent_params = {
            'n_states': 243,
            'n_actions': 9,
            'lr': 0.1,
            'gamma': 0.9,
            'epsilon_start': 1.0,
            'epsilon_decay': 0.9995,
            'epsilon_end': 0.01
        }

        with patch('q_agent.QAgent') as MockQAgentClass:
            mock_instance = MagicMock()
            MockQAgentClass.return_value = mock_instance

            with patch('trainer.train_policy', return_value=({}, mock_instance)):
                pipeline.run_training_pipeline(env_params, agent_params)

            # Verify QAgent was instantiated with n_states and n_actions from agent_params
            MockQAgentClass.assert_called_once_with(
                n_states=agent_params['n_states'],
                n_actions=agent_params['n_actions']
            )


class TestRunEvaluationPipeline:
    """Test run_evaluation_pipeline by mocking evaluator functions."""

    def test_returns_dict_with_correct_keys(self):
        """Verify the structure of the returned dictionary from run_evaluation_pipeline."""
        mock_agent = MagicMock(spec=QAgent)
        n_reps = 5
        seed = 42

        with patch('evaluator.evaluate_match') as mock_eval_match, \
             patch('evaluator.compute_metrics') as mock_compute_metrics:

            mock_eval_match.return_value = {
                'win_rate': 0.5,
                'win_count': 5,
                'draw_count': 2,
                'loss_count': 3,
                'n_matches': 10
            }

            mock_compute_metrics.return_value = {'mean_win_rate': 0.5, 'std_dev': 0.1}

            result = pipeline.run_evaluation_pipeline(mock_agent, n_reps, seed)

        # Assert structure
        assert isinstance(result, dict), "Result must be a dict"
        assert 'agent_vs_baseline' in result, "Missing 'agent_vs_baseline'"
        assert 'baseline_vs_baseline' in result, "Missing 'baseline_vs_baseline'"

    def test_seeds_passed_to_random_agents(self):
        """Verify that seeds are passed correctly to RandomAgent instances.

        The spec says: seed + i for the i-th repetition.
        """
        mock_agent = MagicMock(spec=QAgent)
        n_reps = 3
        base_seed = 123

        with patch('baseline_agent.RandomAgent') as MockRandomAgent:
            mock_ra = MagicMock()
            MockRandomAgent.return_value = mock_ra

            with patch('evaluator.evaluate_match', return_value={
                'win_rate': 0.5, 'win_count': 5, 'draw_count': 2, 'loss_count': 3, 'n_matches': 10
            }) as mock_eval:
                 with patch('evaluator.compute_metrics', return_value={'a': 1}):
                    pipeline.run_evaluation_pipeline(mock_agent, n_reps, base_seed)

        # Filter calls where seed kwarg was passed
        seeded_calls = [call for call in MockRandomAgent.call_args_list if 'seed' in call.kwargs]

        # We expect at least n_reps calls with seeds derived from base_seed + i
        assert len(seeded_calls) >= n_reps, f"Expected at least {n_reps} seeded RandomAgent calls, got {len(seeded_calls)}"

        for call in seeded_calls:
            seed_arg = call.kwargs['seed']
            # Check if this seed matches any base_seed + i
            is_valid = any(seed_arg == (base_seed + i) for i in range(n_reps))
            assert is_valid, f"RandomAgent called with invalid seed {seed_arg}"

    def test_aggregation_logic_with_mocked_metrics(self):
        """Verify that compute_metrics is called and its results are aggregated correctly."""
        mock_agent = MagicMock(spec=QAgent)
        n_reps = 2
        seed = 10

        computed_metrics_history = []
        def capture_compute_metrics(*args, **kwargs):
            computed_metrics_history.append((args, kwargs))
            return {'mean_win_rate': args[0] if args else kwargs.get('win_rate', 0.5)}

        with patch('evaluator.evaluate_match') as mock_eval:
            # Configure side effect to simulate different match results for variety
            def eval_side_effect(*args, **kwargs):
                return {
                    'win_rate': 0.5,
                    'win_count': 5,
                    'draw_count': 2,
                    'loss_count': 3,
                    'n_matches': 10
                }
            mock_eval.side_effect = eval_side_effect

            with patch('evaluator.compute_metrics', side_effect=capture_compute_metrics) as mock_cm:
                result = pipeline.run_evaluation_pipeline(mock_agent, n_reps, seed)

        # We expect compute_metrics to be called for each repetition of agent_vs_baseline AND baseline_vs_baseline.
        assert len(computed_metrics_history) == n_reps * 2, f"Expected {n_reps*2} calls to compute_metrics"