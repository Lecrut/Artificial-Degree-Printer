"""Tests for QAgent from q_agent module."""
import numpy as np
import pytest
import os
from q_agent import QAgent, DEFAULT_LEARNING_RATE, DEFAULT_DISCOUNT_FACTOR, DEFAULT_EPSILON_START


class TestConstants:
    def test_default_learning_rate_is_float(self):
        assert isinstance(DEFAULT_LEARNING_RATE, float)
        assert DEFAULT_LEARNING_RATE == 0.1

    def test_default_discount_factor_is_float(self):
        assert isinstance(DEFAULT_DISCOUNT_FACTOR, float)
        assert DEFAULT_DISCOUNT_FACTOR == 0.99

    def test_default_epsilon_start_is_float(self):
        assert isinstance(DEFAULT_EPSILON_START, float)
        assert DEFAULT_EPSILON_START == 1.0


class TestQAgentInit:
    def test_q_table_initialized_correct_shape(self):
        """Test that q_table is a numpy array with shape (n_states, n_actions) initialized to zeros."""
        agent = QAgent(n_states=10, n_actions=9)
        assert isinstance(agent.q_table, np.ndarray)
        assert agent.q_table.shape == (10, 9)
        assert np.all(agent.q_table == 0)

    def test_n_actions_attribute(self):
        """Test that n_actions attribute is set correctly."""
        agent = QAgent(n_states=10, n_actions=5)
        assert agent.n_actions == 5


class TestChooseAction:
    def test_choose_action_returns_valid_move(self):
        """Test that choose_action returns a move present in possible_moves."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        possible_moves = [1, 4, 7]
        epsilon = 0.5
        action = agent.choose_action(state_hash, possible_moves, epsilon)
        assert action in possible_moves

    def test_choose_action_exploration_returns_valid_move(self):
        """Test that when epsilon=1.0 (full exploration), action is still valid."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        possible_moves = [2]
        epsilon = 1.0
        action = agent.choose_action(state_hash, possible_moves, epsilon)
        assert action in possible_moves

    def test_choose_action_deterministic_with_zero_q_values(self):
        """Test that with zero Q-values and epsilon=0 (exploitation), ties are broken randomly.
        Since all Q-values are 0, any valid move is acceptable. We just check validity."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        possible_moves = [1, 2]
        epsilon = 0.0
        action = agent.choose_action(state_hash, possible_moves, epsilon)
        assert action in possible_moves

    def test_choose_action_with_high_q_value(self):
        """Test that when one move has a significantly higher Q-value, it is chosen with epsilon=0."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        # Manually set Q-values so action 1 has a high value for this state
        agent.q_table[state_hash, 1] = 10.0
        possible_moves = [0, 1]
        epsilon = 0.0
        action = agent.choose_action(state_hash, possible_moves, epsilon)
        assert action == 1

    def test_choose_action_exploration_range(self):
        """Test that actions are chosen within the range of n_actions."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        possible_moves = list(range(9))
        epsilon = 1.0
        action = agent.choose_action(state_hash, possible_moves, epsilon)
        assert 0 <= action < 9


class TestUpdate:
    def test_update_modifies_q_table(self):
        """Test that update method modifies the q_table entry."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        action = 1
        reward = 1.0
        next_state_hash = 1
        done = False
        lr = DEFAULT_LEARNING_RATE
        gamma = DEFAULT_DISCOUNT_FACTOR

        initial_q_value = agent.q_table[state_hash, action]
        agent.update(state_hash, action, reward, next_state_hash, done, lr, gamma)
        updated_q_value = agent.q_table[state_hash, action]

        # Check that the Q-value has changed from the initial zero value
        assert not np.isclose(initial_q_value, updated_q_value)

    def test_update_with_done_true(self):
        """Test update when done=True (no future value term)."""
        agent = QAgent(n_states=10, n_actions=9)
        state_hash = 0
        action = 1
        reward = 5.0
        next_state_hash = 2
        done = True
        lr = 0.5
        gamma = 0.9

        # Expected: Q(s,a) = Q(s,a) + lr * (reward + gamma * 0 - Q(s,a))
        #          = 0 + 0.5 * (5.0 + 0 - 0) = 2.5
        agent.update(state_hash, action, reward, next_state_hash, done, lr, gamma)
        assert np.isclose(agent.q_table[state_hash, action], 2.5)

    def test_update_with_done_false(self):
        """Test update when done=False (future value term included)."""
        agent = QAgent(n_states=10, n_actions=9)
        # Set up next state q-values to have a max of 3.0 at action 2
        next_state_hash = 5
        agent.q_table[next_state_hash, 2] = 3.0

        state_hash = 0
        action = 1
        reward = 1.0
        done = False
        lr = 0.1
        gamma = 0.9

        # Max Q(next_s) is 3.0
        # Expected: Q(s,a) = 0 + 0.1 * (1.0 + 0.9 * 3.0 - 0)
        #          = 0.1 * (1.0 + 2.7) = 0.1 * 3.7 = 0.37
        agent.update(state_hash, action, reward, next_state_hash, done, lr, gamma)
        assert np.isclose(agent.q_table[state_hash, action], 0.37)


class TestSaveLoad:
    def test_save_q_table_creates_file(self, tmp_path):
        """Test that save_q_table creates a file at the specified path."""
        agent = QAgent(n_states=10, n_actions=9)
        filepath = str(tmp_path / "test_q_table.npy")
        agent.save_q_table(filepath)
        assert os.path.exists(filepath)

    def test_save_and_load_q_table(self, tmp_path):
        """Test that loading the saved Q-table restores its values."""
        agent1 = QAgent(n_states=10, n_actions=9)
        # Modify some Q-values
        agent1.q_table[0, 1] = 5.0
        agent1.q_table[2, 3] = 2.5

        filepath = str(tmp_path / "test_q_table.npy")
        agent1.save_q_table(filepath)

        agent2 = QAgent(n_states=10, n_actions=9)
        agent2.load_q_table(filepath)

        assert np.array_equal(agent1.q_table, agent2.q_table)

    def test_load_q_table_file_not_found(self):
        """Test that load_q_table raises FileNotFoundError for non-existent file."""
        agent = QAgent(n_states=10, n_actions=9)
        with pytest.raises(FileNotFoundError):
            agent.load_q_table("non_existent_path.npy")