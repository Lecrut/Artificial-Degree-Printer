from typing import List

import pytest

from baseline_agent import RandomAgent


class TestRandomAgentInit:
    """Tests for RandomAgent initialization."""

    def test_init_no_seed(self) -> None:
        """Test that RandomAgent can be initialized without a seed."""
        agent = RandomAgent()
        # Basic check: instance created successfully and has the method
        assert hasattr(agent, 'choose_action')

    def test_init_with_seed(self) -> None:
        """Test that RandomAgent initializes with a specific seed."""
        seed_val = 42
        agent = RandomAgent(seed=seed_val)
        assert hasattr(agent, 'choose_action')

    def test_init_with_none_seed(self) -> None:
        """Test that providing seed=None is equivalent to no seed (conceptually valid)."""
        agent1 = RandomAgent(seed=None)
        agent2 = RandomAgent()
        # Both should function normally
        assert hasattr(agent1, 'choose_action')
        assert hasattr(agent2, 'choose_action')


class TestRandomAgentChooseAction:
    """Tests for RandomAgent.choose_action method."""

    def test_choose_action_returns_valid_move(self) -> None:
        """Test that choose_action returns a value present in possible_moves."""
        agent = RandomAgent()
        possible_moves = [0, 1, 2, 3, 4, 5, 6, 7, 8]
        state_hash = 12345
        
        action = agent.choose_action(state_hash, possible_moves)
        assert action in possible_moves

    def test_choose_action_single_move(self) -> None:
        """Test behavior when only one move is possible."""
        agent = RandomAgent()
        possible_moves = [4]
        state_hash = 12345
        
        action = agent.choose_action(state_hash, possible_moves)
        assert action == 4

    def test_choose_action_empty_list_raises_value_error(self) -> None:
        """Test that choose_action raises ValueError for empty possible_moves."""
        agent = RandomAgent()
        state_hash = 12345
        
        with pytest.raises(ValueError):
            agent.choose_action(state_hash, [])

    def test_choose_action_deterministic_with_seed(self) -> None:
        """Test that choose_action produces reproducible results with a seed."""
        seed_val = 100
        possible_moves = [0, 3, 6] # Corners
        state_hash = 9999
        
        agent1 = RandomAgent(seed=seed_val)
        agent2 = RandomAgent(seed=seed_val)
        
        actions1 = [agent1.choose_action(state_hash + i, possible_moves) for i in range(10)]
        actions2 = [agent2.choose_action(state_hash + i, possible_moves) for i in range(10)]
        
        assert actions1 == actions2

    def test_choose_action_uniform_distribution_approximation(self) -> None:
        """Test that the distribution of choices approximates uniform over many samples."""
        agent = RandomAgent(seed=42)
        possible_moves = [0, 1]
        num_samples = 1000
        
        counts = [0, 0]
        for _ in range(num_samples):
            action = agent.choose_action(0, possible_moves)
            counts[action] += 1
        
        # With 1000 samples and p=0.5, std_dev is sqrt(n*p*(1-p)) = sqrt(250) ~ 15.8
        # Mean count should be around 500.
        # We use a loose bound here just to ensure it's not always picking one side.
        assert 450 < counts[0] < 550, f"Distribution skewed: {counts}"
        assert 450 < counts[1] < 550, f"Distribution skewed: {counts}"

    def test_choose_action_does_not_modify_possible_moves(self) -> None:
        """Test that choose_action does not mutate the input list."""
        agent = RandomAgent()
        possible_moves = [1, 2, 3]
        original_moves = possible_moves.copy()
        
        _ = agent.choose_action(0, possible_moves)
        assert possible_moves == original_moves

    def test_choose_action_state_hash_ignored(self) -> None:
        """Test that state_hash does not affect the choice validity (randomness only)."""
        agent = RandomAgent()
        possible_moves = [0, 1]
        
        action1 = agent.choose_action(1, possible_moves)
        action2 = agent.choose_action(99999, possible_moves)
        
        # Just ensure valid integers are returned
        assert action1 in possible_moves
        assert action2 in possible_moves