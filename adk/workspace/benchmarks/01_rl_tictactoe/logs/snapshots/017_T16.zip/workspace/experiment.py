"""Entrypoint module that orchestrates the full training and evaluation experiment pipeline for a Q-Learning agent playing Tic-Tac-Toe."""
import csv
import os
from typing import Dict, Any
from pipeline import run_training_pipeline, run_evaluation_pipeline

RESULTS_FILENAME: str = 'results.csv'
FIGURES_DIRNAME: str = 'figures'

def run_experiment() -> None:
    """Runs the complete experiment: training, evaluation, and saving results to CSV. Executes `run_training_pipeline` with default hyperparameters, then `run_evaluation_pipeline`. Aggregates the resulting metrics (agent_win_rate, agent_draw_rate, agent_loss_rate, baseline_win_rate, baseline_draw_rate) and avg_episode_reward into a list of rows. Writes these rows to `results.csv` in the current working directory with headers: method, metric, value. Creates the `figures/` directory if it does not exist (to prepare for future plot generation)."""
    # Define default hyperparameters as per task description
    env_params: Dict[str, Any] = {}
    
    agent_params: Dict[str, Any] = {
        'n_states': 5478,  # Standard state space size for Tic-Tac-Toe
        'n_actions': 9,
        'lr': 0.1,
        'gamma': 0.99,
        'epsilon_start': 1.0,
        'epsilon_decay': 0.995,
        'epsilon_end': 0.01,
        'n_episodes': 2000
    }

    # Step 1: Run Training Pipeline
    training_stats, trained_agent = run_training_pipeline(env_params, agent_params)

    # Extract avg_episode_reward from training stats if available, otherwise use a placeholder or 0
    avg_episode_reward: float = training_stats.get('avg_rewards_100', 0.0) 
    # Note: The spec says 'avg_episode_reward' is a metric. Usually this refers to the final average reward.
    # If training_stats doesn't have it directly, we might need to calculate it or assume the last value in avg_rewards_100 is close enough.
    # For simplicity and robustness, let's grab the last 100-episode avg if available.
    if isinstance(training_stats.get('avg_rewards_100'), list) and len(training_stats['avg_rewards_100']) > 0:
        avg_episode_reward = training_stats['avg_rewards_100'][-1]
    elif isinstance(training_stats.get('avg_rewards_100'), (int, float)):
        avg_episode_reward = training_stats['avg_rewards_100']
    else:
        avg_episode_reward = 0.0

    # Step 2: Run Evaluation Pipeline
    evaluation_metrics: Dict[str, Any] = run_evaluation_pipeline(
        q_agent=trained_agent,
        n_repetitions=5,
        seed=42
    )

    # Step 3: Format results for CSV
    rows: list[list[Any]] = []

    # Add Training Metric
    rows.append(['agent_training', 'avg_episode_reward', avg_episode_reward])

    # Add Agent vs Baseline Metrics
    agent_vs_baseline = evaluation_metrics.get('agent_vs_baseline', {})
    rows.append(['agent_vs_baseline', 'agent_win_rate', agent_vs_baseline.get('agent_win_rate', 0.0)])
    rows.append(['agent_vs_baseline', 'agent_draw_rate', agent_vs_baseline.get('agent_draw_rate', 0.0)])
    rows.append(['agent_vs_baseline', 'agent_loss_rate', agent_vs_baseline.get('agent_loss_rate', 0.0)])

    # Add Baseline vs Baseline Metrics
    baseline_vs_baseline = evaluation_metrics.get('baseline_vs_baseline', {})
    rows.append(['baseline_vs_baseline', 'baseline_win_rate', baseline_vs_baseline.get('baseline_win_rate', 0.0)])
    rows.append(['baseline_vs_baseline', 'baseline_draw_rate', baseline_vs_baseline.get('baseline_draw_rate', 0.0)])

    # Step 4: Write to CSV
    with open(RESULTS_FILENAME, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['method', 'metric', 'value'])
        for row in rows:
            writer.writerow(row)

    # Create figures directory if it doesn't exist
    os.makedirs(FIGURES_DIRNAME, exist_ok=True)
