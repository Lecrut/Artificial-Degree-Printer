"""Manages the training loop for a Q-Learning agent against a random baseline environment."""
import numpy as np
from typing import Tuple, Dict, Any, List
from environment import TicTacToeEnv
from q_agent import QAgent
DEFAULT_LR: float = 0.1
DEFAULT_GAMMA: float = 0.99
EPSILON_DECAY_RATE: float = 0.995
MIN_EPSILON: float = 0.01

def train_episode(env: TicTacToeEnv, agent: QAgent, opponent: Any, epsilon: float, lr: float, gamma: float) -> Tuple[float, int]:
    """Runs a single episode of Tic-Tac-Toe between the agent and an opponent.

    The agent acts as Player X (the learner) and the opponent acts as Player O. Steps proceed until the game terminates or draws. The agent updates its Q-table after each step using the Bellman equation via `agent.update`. Opponent actions are chosen via the provided callable.

    Args:
        env: The TicTacToe environment instance to use for simulation.
        agent: The QAgent instance that learns from experience.
        opponent: A callable taking the current `TicTacToeEnv` instance and returning an action index (int). This function is responsible for selecting a valid move based on the environment's state.
        epsilon: Exploration rate passed to `agent.choose_action`. Must be in [0, 1].
        lr: The learning rate used for `agent.update`. Derived from agent_params in train_policy.
        gamma: The discount factor used for `agent.update`. Derived from agent_params in train_policy.

    Returns:
        tuple: A tuple containing:
            - total_reward (float): The sum of rewards received by the agent throughout the episode.
            - num_steps (int): The number of steps taken in the episode."""
    obs, _ = env.reset()
    done = False
    truncated = False
    total_reward = 0.0
    step_count = 0
    while not (done or truncated):
        moves = env._get_available_moves()
        action = agent.choose_action(obs, moves, epsilon)
        next_obs, reward, done, truncated, _ = env.step(action)
        total_reward += reward
        agent.update(obs, action, reward, next_obs, done, lr, gamma)
        obs = next_obs
        step_count += 1
    return (total_reward, step_count)

def train_policy(n_episodes: int, env_params: Dict[str, Any], agent_params: Dict[str, Any]) -> Tuple[QAgent, Dict[str, Any]]:
    """Executes the full training process for a specified number of episodes.

    Initializes a new `TicTacToeEnv` and a new `QAgent` using parameters from `agent_params`. Iterates through `n_episodes`, calling `train_episode` for each with epsilon decay. Returns the trained agent and aggregated statistics to allow the consumer (`pipeline.py`) to access the learned model and metrics.

    Note: The experiment time limit (180s) constrains the feasible range of `n_episodes`. Values around 5,000 are sufficient for Tic-Tac-Toe convergence within this budget.

    Args:
        n_episodes: Total number of training episodes to run. Recommended range: [1,000, 5,000] to fit within time limits while ensuring convergence.
        env_params: Dictionary of parameters for `TicTacToeEnv` initialization (currently unused but kept for consistency).
        agent_params: Dictionary containing hyperparameters for the agent and training. Keys:
            - 'n_states' (int): Number of possible states for Q-table initialization.
            - 'n_actions' (int): Number of actions (9).
            - 'lr' (float): Learning rate.
            - 'gamma' (float): Discount factor.
            - 'epsilon_start' (float): Initial exploration rate.
            - 'epsilon_decay' (float): Multiplicative decay factor for epsilon per episode. Final epsilon is max(`MIN_EPSILON`, `epsilon_start` * `epsilon_decay**episode_index`).
            - 'epsilon_end' (float, optional): Minimum exploration rate floor (defaults to MIN_EPSILON).

    Returns:
        tuple: A tuple containing:
            - trained_agent (QAgent): The fully trained Q-Agent instance, ready for evaluation. This must be returned so `pipeline.py` can access the learned Q-table.
            - stats (dict): A dictionary containing final training statistics:
                - 'final_epsilon' (float): The value of epsilon after all episodes.
                - 'total_episodes' (int): The number of episodes completed.
                - 'avg_reward_history' (List[float]): List of average rewards over sliding windows (e.g., last 100 episodes) to show convergence."""
    env = TicTacToeEnv()
    agent = QAgent(agent_params['n_states'], agent_params['n_actions'])
    lr = agent_params['lr']
    gamma = agent_params['gamma']
    epsilon_start = agent_params['epsilon_start']
    epsilon_decay = agent_params['epsilon_decay']
    epsilon_end = agent_params.get('epsilon_end', MIN_EPSILON)
    reward_history: List[float] = []
    window_size = 100
    for i in range(n_episodes):
        current_epsilon = max(epsilon_end, epsilon_start * epsilon_decay ** i)
        reward, _ = train_episode(env, agent, lambda e: e._get_available_moves()[np.random.randint(len(e._get_available_moves()))], current_epsilon, lr, gamma)
        reward_history.append(reward)
    final_epsilon = max(epsilon_end, epsilon_start * epsilon_decay ** (n_episodes - 1))
    avg_reward_history: List[float] = []
    for i in range(window_size, n_episodes + 1):
        avg_reward_history.append(np.mean(reward_history[i - window_size:i]))
    stats: Dict[str, Any] = {'final_epsilon': final_epsilon, 'total_episodes': n_episodes, 'avg_reward_history': avg_reward_history}
    return (agent, stats)
