from random_agent import RandomAgent
import numpy as np


def test_act_returns_valid_move() -> None:
    """Test that RandomAgent returns a valid move index for non-terminal states."""
    agent = RandomAgent()
    rng = np.random.default_rng(42)

    # Construct a state with exactly one valid empty move (index 3)
    # The implementation expects 'board' key mapping indices 0-8 to cell values.
    state_with_moves: dict[int, str | None] = {
        0: "O",
        1: "O",
        2: "O",
        3: None,
        4: "X",
        5: "X",
        6: None,
        7: None,
        8: None
    }

    action = agent.act(state_with_moves, rng)

    # Specification check: act() must return an integer index when valid moves exist.
    assert isinstance(action, int), f"act() must return an integer index, got {type(action)}"
    
    # Specification check: Return value must be a valid cell identifier (0-8) found in state keys.
    assert action in state_with_moves, f"Action {action} is not a valid key in the state dictionary."


def test_act_returns_minus_one_for_terminal() -> None:
    """Test that RandomAgent returns -1 when no valid moves exist."""
    agent = RandomAgent()
    rng = np.random.default_rng(42)

    # Construct a terminal state with no empty cells.
    full_state_dict: dict[int, str] = {
        0: "O",
        1: "O",
        2: "O",
        3: "X",
        4: "X",
        5: "X",
        6: "X",
        7: "O",
        8: "X"
    }

    action_terminal = agent.act(full_state_dict, rng)
    assert action_terminal == -1, "act() must return -1 when no valid moves exist."