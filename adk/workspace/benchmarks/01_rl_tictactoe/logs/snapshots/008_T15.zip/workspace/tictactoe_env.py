"""Defines the Tic-Tac-Toe game environment with state representation, move validation, and win/draw detection for reinforcement learning."""
import numpy as np
from typing import Optional
BOARD_SIZE: int = 9
EMPTY_CELL: int = 0
PLAYER_X: int = 1
PLAYER_O: int = -1

class TicTacToeEnv:
    """A class managing the Tic-Tac-Toe game state, including board initialization, move validation, and terminal condition tracking."""
    board: np.ndarray
    current_player: int
    history: list[int]
    terminal_state: bool
    winner: Optional[str]
    draw: bool

    def reset(self) -> dict:
        """Creates a new empty board and sets the first player to move. Returns state dict with board, current_player, history, winner, and draw."""
        self.board = np.zeros(BOARD_SIZE, dtype=np.int32)
        self.current_player = PLAYER_X
        self.history = []
        self.terminal_state = False
        self.winner = None
        self.draw = False
        return {'board': self.board.copy(), 'current_player': self.current_player, 'history': self.history.copy(), 'winner': self.winner, 'draw': self.draw}

    def step(self, action: int) -> tuple[np.ndarray, float, bool, bool, dict]:
        """Executes a turn by the current player. Returns observation, reward, terminated, truncated, and info dict."""
        valid_move = True
        if not (0 <= action < BOARD_SIZE and self.board[action] == EMPTY_CELL):
            obs = self.board.copy()
            reward = 0.0
            terminated = False
            truncated = False
            info = {'valid_move': False, 'game_over': False}
        else:
            self.board[action] = self.current_player
            obs = self.board.copy()
            history_copy = self.history + [self.current_player]
            self.history = history_copy
            is_win, win_val = check_win(self.board)
            is_draw_result = check_draw(self.board)
            game_over = is_win or is_draw_result
            if is_win:
                reward = 1.0 if self.current_player == is_win else -1.0
                terminated = True
            elif is_draw_result:
                reward = 0.0
                terminated = True
                self.draw = True
            else:
                reward = 0.0
                terminated = False
                truncated = False
                self.current_player = PLAYER_O if self.current_player == PLAYER_X else PLAYER_X
            valid_move = True
        info = {'valid_move': valid_move, 'game_over': game_over}
        return (obs, reward, terminated, truncated, info)

    def __init__(self) -> None:
        """Initializes the Tic-Tac-Toe environment state with a new empty board and first player."""
        self.board: np.ndarray = np.zeros(BOARD_SIZE, dtype=np.int32)
        self.current_player: int = PLAYER_X
        self.history: list[int] = []
        self.terminal_state: bool = False
        self.winner: Optional[str] = None
        self.draw: bool = False

def get_valid_moves(env: TicTacToeEnv) -> list[int]:
    """Returns a sorted list of integer indices representing all currently empty cells."""
    valid = []
    for i in range(BOARD_SIZE):
        if env.board[i] == EMPTY_CELL:
            valid.append(i)
    return valid
