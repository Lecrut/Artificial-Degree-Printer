"""Implements the Q-Learning agent with epsilon-greedy exploration and tabular policy updates for finite-state environments."""
import numpy as np
from typing import List, Dict, Tuple
BOARD_SIZE = 9

class QLearningAgent:
    """A class representing an agent that learns a policy using tabular Q-Learning."""
    q_table: Dict[Tuple[int, ...], np.ndarray]
    learning_rate: float
    discount_factor: float
    epsilon: float
    initial_epsilon: float
    decay: float

    def __init__(self, learning_rate: float, discount_factor: float, initial_epsilon: float, decay: float) -> None:
        """Initializes the agent with hyperparameters and creates an empty Q-table."""
        self.q_table = {}
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.initial_epsilon = initial_epsilon
        self.decay = decay
        self.epsilon = initial_epsilon

    def act(self, state: np.ndarray, valid_moves: List[int]) -> int:
        """Returns an integer action index from valid_moves using epsilon-greedy policy."""
        import random
        if not self.q_table.get(tuple(state)):
            return random.choice(valid_moves)

    def learn(self, state: np.ndarray, action: int, reward: float, next_state: np.ndarray, terminated: bool) -> None:
        """Updates the Q-value for the state-action pair using the Bellman equation."""
        state_tuple = tuple(state)
        if state_tuple not in self.q_table:
            self.q_table[state_tuple] = np.zeros(BOARD_SIZE)
        q_current = self.q_table[state_tuple][action]
        if terminated:
            target = reward
        else:
            next_state_tuple = tuple(next_state)
            max_q_next = 0.0
            if next_state_tuple in self.q_table:
                max_q_next = np.max(self.q_table[next_state_tuple])
            target = reward + self.discount_factor * max_q_next
        new_q = q_current + self.learning_rate * (target - q_current)
        self.q_table[state_tuple][action] = new_q

    def reset(self) -> None:
        """Resets the internal exploration rate epsilon to initial_epsilon."""
        np.random.seed(42)
        self.epsilon = self.initial_epsilon
