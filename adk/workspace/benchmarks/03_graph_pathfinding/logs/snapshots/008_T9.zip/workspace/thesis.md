## Rozdział 2: Tło i przegląd najnowszych prac
W kontekście rosnących wymagań wobec systemów autonomii mobilnej oraz symulacji logistycznych, efektywne wyszukiwanie ścieżek na siatkach przestrzennych pozostaje fundamentalnym problemem informatyki obliczeniowej. Mimo upowszechnienia metod uczenia maszynowego, klasyczne algorytmy przeszukiwania grafów stanowią trzon wielu rozwiązań przemysłowych ze względu na ich determinizm, gwarancję optymalności (w przypadku bezwzględnej heurystyki) oraz niski narzut pamięciowy w fazie wnioskowania\cite{tang2026scaling}. Niniejszy rozdział omawia teoretyczne podstawy algorytmu Dijkstry oraz modyfikacji A*, skupiając się na mechanizmie ważenia heurystyki (	extit{weighted A*}) i jego wpływie na równowagę między kosztem obliczeniowym a jakością ścieżki.\n
### 2.1 Algorytm Dijkstry i jego ograniczenia w dużych przestrzeniach stanów

Klasyczny algorytm Dijkstry, będący szczególnym przypadkiem przeszukiwania pierwszego brzegu (BFS) na grafach o nieujemnych wagach krawędzi, gwarantuje znalezienie ścieżki minimalnego kosztu przez priorytetyzację węzłów według dotychczasowego koszty dojścia $g(n)$\cite{tang2025routing}. W implementacji na siatkach dwuwymiarowych z ośmioma kierunkami ruchu (w tym przesunięciami po przekątnych), algorytm ten wymaga eksploracji wierzchołków zgodnie ze stożkiem rosnącego kosztem od punktu startowego. W gęsto zabudowanych przestrzeniach, takich jak siatki z wysokim stopniem skomplikowania (	extit{obstacle density}), Dijkstra generuje duże obszary eksploracji (ang. 	extit{nodal expansion}), co prowadzi do kwadratowej złożoności czasowej w najgorszym przypadku względem rozmiaru siatki. Choć algorytm ten służy jako punkt odniesienia (	extit{baseline}) dla optymalności w niniejszej pracy, jego brak heurystycznego kierowania czyni go nieefektywnym w kontekście wymagającym szybkiego znalezienia dowolnej dopuszczalnej ścieżki na dużych mapach\cite{ahmadi2024resource}.\n
### 2.2 Algorytm A* i heurystyka oktylowa

Algorytm A* poprawia wydajność Dijkstry, wprowadzając funkcję priorytetu $f(n) = g(n) + h(n)$, gdzie $h(n)$ jest heurystyką estymującą koszt dojścia od węzła $n$ do celu. Dla zachowania optymalności, heurystyka musi być 	extit{dozwolona} (	extit{admissible}), czyli nigdy nie przeszacowywać rzeczywistego kosztu\cite{casasramos2025declarealign}. W przestrzeniach siatkowych z dozwolonymi ruchami w ośmiu kierunkach, najkrótsza droga Euklidesowa (po krzywych) nie jest precyzyjna, natomiast metryka Manhattanu jest zbyt konserwatywna. 

Kluczowym elementem niniejszego modelu jest wykorzystanie 	extit{odległości oktylowej} (	extit{octile distance}), zdefiniowanej jako:
\begin{equation}
    h_{octile}(n, G) = D_1 \cdot |x_n - x_G| + D_2 \cdot (|y_n - y_G| - |x_n - x_G|)
\end{equation}
dzieje $D_1$ to koszt ruchu prostego (zwykle 1), a $D_2$ to koszt ruchu po przekątnej (zwykle $\sqrt{2}$). W implementacji kodu źródłowego projektu, funkcja ta jest zaimplementowana w module 	exttt{heuristics.py} pod nazwą 	exttt{octile_distance}, co zapewnia precyzyjną i obliczeniowo lekką estymację pozostałej odległości. Heurystyka oktylowa jest standardem w grach symulacyjnych oraz robotyce mobilnej ze względu na swoją zgodność z topologią ruchu po siatce\cite{wang2026vikpath}.\n
### 2.3 Ważony A* i kompromis wydajnościowo-optymalnościowy

Mimo doskonałych właściwości optymalnych, standardowy A* może nadal rozwijać nadmiarowe węzły w przypadku, gdy heurystyka jest 	extit{consistent}, ale nie dostarcza wystarczającego informacji o kierunku do celu. Rozwiązaniem jest 	extit{Weighted A*}, w którym priorytet przeliczany jest jako:
\begin{equation}
    f(n) = g(n) + w \cdot h(n)
\end{equation}
dzieje $w > 1$ jest współczynnikiem ważenia. Powiększenie $w$ nadaje heurystyce większy wpływ na wybór ścieżki, wymuszając algorytmowi bardziej 	extit{zachłanne} (ang. 	extit{greedy}) kierowanie się w stronę celu. Zgodnie z literaturą przedmiotu, wzrost wagi prowadzi do istotnego zmniejszenia liczby rozwiniętych węzłów (	extit{expanded nodes}), co przyspiesza czas działania\cite{abbasov2025optimal}. W zamian za ten przyrost efektywności, gwarancja optymalności ścieżki zostaje złamana. Zamiast kosztu $C^*$, algorytm zagwarantuje znalezienie ścieżki o koszcie $C \le w \cdot C^*$. Różnica ta definiuje 	extit{suboptimality gap}, który stanowi główną metrykę oceny w niniejszym eksperymencie.\n
Dobór optymalnej wartości wagi jest problemem nierozwiązywalnym analitycznie dla dynamicznych map, dlatego też w pracach empirycznych stosuje się analizę wrażliwości (	extit{sensitivity analysis}) na zbiorze losowo generowanych siatek \cite{bokan2024slope}. W niniejszym projekcie, doborowi parametru $w$ oraz ocenie jego wpływu na liczbę rozwiniętych węzłów i suboptimality gap poświęcony jest rozdział trzeci.\n
### 2.4 Przejście do eksperymentu

W przeciwieństwie do najnowszych podejść opartych na głębokim uczeniu, które wymagają kosztownego szkolenia (	extit{training}) lub działają w przestrzeniach ciągłych \cite{zhao2026customizable}, 	extit{Weighted A*} oferuje natychmiastowe wnioskowanie. Niniejsza praca uzupełnia lukę badawczą poprzez precyzyjne zmierzenie tego kompromisu na losowych siatkach z przeszkodami. Eksperyment polega na bezpośrednim porównaniu algorytmu Dijkstry (	exttt{search_grid}) z implementacją 	extit{Weighted A*} (	exttt{search_weighted_astar}), przy zachowaniu tego samego generatora siatek (	exttt{generate_obstacle_grid}) i ziaren losowości (	exttt{config.py:SEED}).

## Rozdział 3: Konfiguracja eksperymentu
Aby zweryfikować hipotezę badawczą dotyczącą kompromisu między wydajnością a optymalnością ścieżki, zaprojektowano serię symulacji na losowo generowanych siatkach przestrzennych. Doświadczenie to bezpośrednio porównuje klasyczny algorytm Dijkstry (	exttt{search_grid}) z proponowaną modyfikacją 	extit{Weighted A*} (	exttt{search_weighted_astar}), zapewniając przy tym identyczne warunki startowe dla obu metod.

\subsection{Generator siatek i przestrzeń stanów}
Podstawą porównania jest deterministyczny generator map z przeszkodami, implementowany przez funkcję 	exttt{core.py:generate_obstacle_grid}. W celu zachowania powtarzalności wyników (reproducibility), losowanie konfiguracji przeszkód oraz par startowych i docelowych jest sterowane ustalonym ziarnem losowości (	exttt{config.py:SEED}). Każdy eksperyment generuje zbiór unikalnych map o zadanych parametrach topologicznych, co pozwala na agregację danych statystycznych.

\subsection{Parametry konfiguracyjne i dobór prób}
W badaniu uwzględniono trzy kluczowe parametry konfiguracji generatora:
\begin{enumerate}
    \item \textbf{Rozmiar siatki (	exttt{config.py:GRID_SIZE})}: Badano wpływ wielkości przestrzeni na skalowalność algorytmów. Przyjęto zakres od małych map $20\times20$ (stanowiska testowe) do dużych obszarów $200\times200$ i $500\times500$ (symulacje logistyczne). 
    \item \textbf{Gęstość przeszkód (	exttt{config.py:OBSTACLE_DENSITY})}: Zdefiniowano rozrzut gęstości na przedziale $[0.1, 0.5]$, aby obejrzeć zarówno otwarte przestrzenie, jak i obszary silnie zabudowane, gdzie różnice w ekspansji węzłów powinny być najbardziej widoczne.
    \item \textbf{Liczba powtórzeń (	exttt{experiment.py:N_RUNS})}: Dla każdej konfiguracji parametrycznej uruchomiono $N$ niezależnych symulacji (zdefiniowanych jako 	exttt{experiment.py:N_RUNS}), co umożliwia oszacowanie wariancji wyników i zapewnienie istotności statystycznej.
\end{enumerate}

W kontekście samej modyfikacji algorytmu, głównym badanych czynnikiem jest waga heurystyki $w$. Zbiór wag badanych (	exttt{experiment.py:WEIGHTS}) obejmuje wartości z przedziału $(1.0, 3.0]$, gdzie wartość $1.0$ odpowiada klasycznemu A* (optymalnemu), a wyższe wartości wprowadzają przybliżenie kosztem optymalności.

\subsection{Metryki oceny i protokół pomiaru}
Ocenę efektywności przeprowadzono w oparciu o cztery główne metryki, zbierane dla każdej pary startowo-końcowej na danej mapie:
\begin{itemize}
    \item \textbf{Liczba rozwiniętych węzłów (	exttt{avg_expanded_nodes}, 	exttt{std_expanded_nodes})}: Miara złożoności czasowej wirtualnego procesu przeszukiwania. W algorytmie Dijkstry odpowiada to liczbie usunięć z priorytetu kolejki, a w A* — analogicznie liczbie rozważeń ścieżek do celu.
    \item \textbf{Koszt znalezionej ścieżki (	exttt{path_cost_astar})}: Suma wag krawędzi na znalezionej trasie. Dla algorytmu bazowego (Dijkstra) jest to wartość referencyjna $C^*$.
    \item \textbf{Suboptimality Gap}: Zdefiniowano jako iloraz kosztu ścieżki znalezionej przez Weighted A* i optymalnego kosztu Dijkstry ($\frac{C_{A^*}}{C_{Dijkstra}} - 1$). Metryka ta bezpośrednio ilustruje cenę, jaką płaci się za przyspieszenie wyszukiwania.
\end{itemize}

Całość procesu uruchamiania eksperymentu jest zautomatyzowana w module 	exttt{experiment.py:run_experiment}, który iteruje po kartezjańskim iloczynie parametrów i wag, zbierając surowe wyniki. Finalna wizualizacja danych oraz generowanie wykresów porównawczych realizowane są następnie przez funkcję 	exttt{figures.py:generate_figures}.
